/** 
 * @file collection.cpp
 * @note 采图步骤：
 * [01] 启动OpenCV摄像头图像捕获
 * [02] 图像显示与存储
 */
 
#include <fstream>
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../include/common.hpp"
#include <string>                // 字符串类
#include <sys/stat.h>            // 获取文件属性
#include <sys/types.h>           // 基本系统数据类型
#include "../include/uart.hpp"   // 串口通信

typedef enum
{
    battery=0,
    block=1,
    bridge=2,
    burger=3,
    car=4,
    company=5,
    cone=6,
    crosswalk=7,
    pedestrian=8,
    school=9,
}ImageKind;

int main(int argc, char const *argv[])
{
    // USB转串口的设备名为/dev/ttyUSB0
    shared_ptr<Uart> uart = make_shared<Uart>("/dev/ttyUSB0"); // 初始化串口驱动
    if (uart == nullptr)
    {
        std::cout << "Create Uart-Uart Error!" << std::endl;
        return -1;
    }
    // 串口初始化，打开串口设备及配置串口数据格式
    int ret = uart->open();
    if (ret != 0)
    {
        std::cout << "Uart Open failed!" << std::endl;
        return -1;
    }
    uart->startReceive(); // 启动数据接收子线程
    // 摄像头初始化
    VideoCapture capture("/dev/video0");
    if (!capture.isOpened())
    {
        std::cout << "can not open video device " << std::endl;
        return 1;
    }

    capture.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M','J','P','G'));
    capture.set(CAP_PROP_FRAME_WIDTH, COLSIMAGE);  // 设置图像的列
    capture.set(CAP_PROP_FRAME_HEIGHT, ROWSIMAGE); // 设置图像的行

    ImageKind imgkind;
    int ImageKind_Index;
    string imgPath;
    int frameInterval = 1;  // 每隔10帧保存一张图片
    int frameCounter = 0;

    cout << "battery=0\nblock=1\nbridge=2\nburger=3\ncar=4\ncompany=5\ncone=6\ncrosswalk=7\npedestrian=8\nschool=9\n" << endl;
    cout << "IMAGE KIND OF COLLECT:";

    cin >> ImageKind_Index;
    imgkind = ImageKind(ImageKind_Index);

    while (true)
    {
        // 读取图像
        Mat frame;
        if (!capture.read(frame))
        {
            break;
        }

        frameCounter++;
            
        // 图像采集
        static int index = 183;
        if(uart->keypress)
        {
            uart->keypress = false;
            switch(imgkind)
            {
                case battery:{ imgPath = "../res/samples/train/battery/"; break; }
                case block:{ imgPath = "../res/samples/train/block/"; break; }
                case bridge:{ imgPath = "../res/samples/train/bridge/"; break; }
                case burger:{ imgPath = "../res/samples/train/burger/"; break; }
                case car:{ imgPath = "../res/samples/train/car/"; break; }
                case company:{ imgPath = "../res/samples/train/company/"; break; }
                case cone:{ imgPath = "../res/samples/train/cone/"; break; }
                case crosswalk:{ imgPath = "../res/samples/train/crosswalk/"; break; }
                case pedestrian:{ imgPath = "../res/samples/train/pedestrian/"; break; }
                case school:{ imgPath = "../res/samples/train/school/"; break; }
            }
            
            string name = ".jpg";
            index++;
            name = imgPath + to_string(index) + ".jpg";
            struct stat buffer;
            if (stat(imgPath.c_str(), &buffer) != 0) // 判断文件夹是否存在
            {
                string command;
                command = "mkdir -p " + imgPath;
                system(command.c_str()); // 利用os创建文件夹
            }
            imwrite(name, frame);
            cout << "Saved image: " << index << ".jpg" << std::endl;
        }

        putText(frame, to_string(index), Point(10, 30), cv::FONT_HERSHEY_TRIPLEX, 1, cv::Scalar(0, 0, 254), 1, CV_AA); // 显示图片保存序号
        imshow("imgFrame", frame);
        if (waitKey(1) == 27)  // 按ESC键退出
        {
            break;
        }
    }

    return 0;
}