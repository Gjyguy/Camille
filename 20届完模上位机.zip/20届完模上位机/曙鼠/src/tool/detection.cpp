/**
 * @file detection.cpp
 * @brief 目标检测
 */
#include "../include/common.hpp"     //公共类方法文件
#include "../include/detection.hpp"  //百度Paddle框架移动端部署
#include "../src/motion.cpp"                //智能车运动控制类
#include "../src/preprocess.cpp"            //图像预处理类
#include <iostream>
#include <opencv2/highgui.hpp> //OpenCV终端部署
#include <opencv2/opencv.hpp>  //OpenCV终端部署
#include <signal.h>
#include <unistd.h>

using namespace std;
using namespace cv;

int main(int argc, char const *argv[]) {
  Preprocess preprocess;    // 图像预处理类
  Motion motion;            // 运动控制类
  VideoCapture capture;     // Opencv相机类

  // 目标检测类(AI模型文件)
  shared_ptr<Detection> detection = make_shared<Detection>(motion.params.model);
  detection->score = motion.params.score; // AI检测置信度

  // USB摄像头初始化
  if (motion.params.debug)
    capture = VideoCapture(motion.params.video); // 打开本地视频
  else
    capture = VideoCapture("/dev/video0"); // 打开摄像头
  if (!capture.isOpened()) {
    printf("can not open video device!!!\n");
    return 0;
  }
    capture.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M','J','P','G'));
    capture.set(CAP_PROP_FRAME_WIDTH, 320);  // 设置图像的列数
    capture.set(CAP_PROP_FRAME_HEIGHT, 240); // 设置图像的行数
    capture.set(CAP_PROP_FPS, 120);               // 设置帧率

  // 初始化参数
  Mat img;

  while (1) 
  {
    //[01] 视频源读取
    if (!capture.read(img))
      continue;
    if (motion.params.saveImg && !motion.params.debug) // 存储原始图像
      savePicture(img);

    //[02] 图像预处理
    // Mat imgCorrect = preprocess.correction(img);         // 图像矫正

    //[03] 启动AI推理
    detection->inference(img);

    detection->drawBox(img); // 图像绘制AI结果
    imshow("detection", img);
    waitKey(1);    // 等待显示

  }

  capture.release();
  return 0;
}