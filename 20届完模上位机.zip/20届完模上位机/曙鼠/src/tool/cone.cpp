#include <fstream>           
#include <iostream>           
#include <opencv2/opencv.hpp> 

#define ROWSIMAGE 240 // 结果图行数（与图像高度一致）
#define RESULT_COL 320 // 结果图列数（与图像宽度一致）

using namespace cv;
using namespace std;

int main()
{
  // 打开摄像头
  VideoCapture capture("/dev/video0", CAP_V4L2);
  if (!capture.isOpened())
  {
    cout << "can not open video device " << endl;
    return 1;
  }

  capture.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M','J','P','G'));
  capture.set(CAP_PROP_FRAME_WIDTH, RESULT_COL);  // 设置图像的列数
  capture.set(CAP_PROP_FRAME_HEIGHT, ROWSIMAGE); // 设置图像的行数

    while (1)
    {
        Mat img;
        capture >> img;

        if (img.empty())
        {
            std::cerr << "Error loading image!" << std::endl;
            return -1;
        }
        Mat hsv;
        Mat imageCorrect = img.clone();
        cvtColor(imageCorrect, hsv, COLOR_BGR2HSV);
        // 定义黄色的HSV范围
        Scalar lowerYellow(15, 100, 60);
        Scalar upperYellow(35, 255, 255);
        // 定义红色的HSV范围
        Scalar lower_red1(0, 50, 50);     // H: 0-10 (对应0-20°实际色相)
        Scalar upper_red1(10, 255, 255);
        Scalar lower_red2(170, 50, 50);  // H: 170-180 (对应340-360°实际色相)
        Scalar upper_red2(180, 255, 255);
        // 定义粉色的HSV范围
        Scalar lower_purple(135, 100, 75);
        Scalar upper_purple(150, 255, 255);
        Mat Maskcone;
        Mat Maskred;
        Mat Maskpink;

        inRange(hsv, lowerYellow, upperYellow, Maskcone);
        inRange(hsv, lower_red2, upper_red2, Maskred);
        inRange(hsv, lower_purple, upper_purple, Maskpink);

        vector<vector<Point>> contours1;
        vector<vector<Point>> contours2;
        vector<vector<Point>> contours3;

        findContours(Maskcone, contours1, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
        findContours(Maskred, contours2, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
        findContours(Maskpink, contours3, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

        // 选取距离最近的锥桶   
        if (!contours1.empty())
        {       
            Rect Cone;
            for (const auto& contour : contours1)
            {
                Rect Tempcone = boundingRect(contour);
                Cone = Tempcone;
                if (Cone.height * Cone.width < 500)
                {
                    continue;
                }
                rectangle(img, Cone, Scalar(0, 0, 255), 3);
            }
        }

        // 选取距离最近的红人 
        if (!contours2.empty())
        {
            Rect Cone;
            for (const auto& contour : contours2)
            {
                Rect Tempcone = boundingRect(contour);
                Cone = Tempcone;
                if (Cone.height * Cone.width < 500)
                {
                    continue;
                }
                rectangle(img, Cone, Scalar(0, 0, 255), 3);
            }
        }

        // 选取距离最近的粉人
        if (!contours3.empty())
        {
            Rect Cone;
            for (const auto& contour : contours3)
            {
                Rect Tempcone = boundingRect(contour);
                Cone = Tempcone;
                if (Cone.height * Cone.width < 500)
                {
                    continue;
                }
                rectangle(img, Cone, Scalar(0, 0, 255), 3);
            }
        }

        imshow("rgb", img);
        //imshow("hsv", imageCorrect);
        waitKey(1);

    }

    return 0;
}