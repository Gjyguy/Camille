#include "../include/detection.hpp"      
#include "../include/uart.hpp"        //串口通信驱动
#include "motion.cpp"                 //智能车运动控制类
#include "mapping.cpp"                //智能车运动控制类
#include "preprocess.cpp"             //图像预处理类
#include <iostream>
#include <opencv2/highgui.hpp>        //OpenCV终端部署
#include <opencv2/opencv.hpp>         //OpenCV终端部署
#include <signal.h>
#include <mutex>
#include <unistd.h>                   //百度Paddle框架移动端部署
#include "../include/common.hpp"      //公共类方法文件
#include "recognition/tracking.cpp"   //赛道识别基础类
#include "recognition/crossroad.cpp"  //赛道识别基础类
#include "recognition/ring.cpp"       //赛道识别基础类
#include "controlcenter.cpp"          //控制中心计算类
#include "detection/parking.cpp"      //AI检测：停车区
#include "detection/obstacle.cpp"     //AI检测：障碍区
#include "detection/bridge.cpp"       //AI检测：坡道区
//#include "detection/layby.cpp"        //AI检测：临时停车区
#include "detection/laybynew.cpp"        //AI检测：临时停车区
#include "detection/catering.cpp"     //AI检测：餐饮区
#include "detection/charging.cpp"  
#include <future>

using namespace std; //创建名称空间
using namespace cv;

int main()
{
    Preprocess preprocess;    // 图像预处理类
    Motion motion;            // 运动控制类
    Tracking tracking;        // 赛道识别类
    Crossroad crossroad;      // 十字道路识别类
    Ring ring;
    ControlCenter ctrlCenter; // 控制中心计算类
    Mapping mapping;          // 逆透视类
    Bridge bridge;            // 坡道区检测类
    Parking parking;          // 停车区检测类
    Obstacle obstacle;
    Layby layby;
    Charging charging;
    Catering catering;        // 快餐店检测类
    VideoCapture capture;     // Opencv相机类

    // 目标检测类(AI模型文件)
    shared_ptr<Detection> detection = make_shared<Detection>(motion.params.model);
    detection->score = motion.params.score; // AI检测置信度

    // USB转串口初始化： /dev/ttyUSB0
    shared_ptr<Uart> uart = make_shared<Uart>("/dev/ttyUSB0"); // 初始化串口驱动
    int ret = uart->open();
    if (ret != 0) {
      printf("[Error] Uart Open failed!\n");
      return -1;
    }
    uart->startReceive(); // 启动数据接收子线程
    cout<<"----------------等待发车！----------------"<<endl;
    while (!uart->keypress)
    {
        waitKey(1);
    }
    cout<<"--------------把风吹到杭电！--------------"<<endl;
    uart->keypress = false;
    uart->buzzerSound(uart->BUZZER_OK); // 祖传提示音效

    // USB摄像头初始化
    if(motion.params.debug)
        capture = VideoCapture(motion.params.video); // 打开本地视频
    else
        capture = VideoCapture("/dev/video0"); // 打开摄像头
    
    capture.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M','J','P','G'));
    capture.set(CAP_PROP_FRAME_WIDTH, 320);  // 设置图像的列数
    capture.set(CAP_PROP_FRAME_HEIGHT, 240); // 设置图像的行数
    capture.set(CAP_PROP_FPS, 120); 

    double width = capture.get(CAP_PROP_FRAME_WIDTH);   // 读取图像的宽度
    double height = capture.get(CAP_PROP_FRAME_HEIGHT); // 读取图像的高度
    double rate = capture.get(CAP_PROP_FPS);            // 读取图像的帧率

    // 初始化参数
    Scene scene = Scene::NormalScene;     // 初始化场景：常规道路
    Scene sceneLast = Scene::NormalScene; // 记录上一次场景状态

    std::future<void> future;
    float detFPS=0;
    bool AIFlag = false;
    CenterType centerType = CenterType::Mid; // 中线类型
    bool way=false;//起始点寻找方式
    Mat img;
    
    while(1)
    {
        //[01] 视频源读取&&帧率获取
        if(motion.params.FPS)
        {
            static auto preTime = chrono::steady_clock::now(); 
            auto startTime = chrono::steady_clock::now();
    
            auto frameDuration = chrono::duration_cast<chrono::milliseconds>(startTime - preTime).count();
            detFPS = frameDuration > 0 ? 1000.0f / frameDuration : 0.0f; 
            preTime = startTime;

            //cout << "Run frame time: " << frameDuration << "ms" << std::endl;
            //cout << "FPS: " << detFPS << std::endl; 
        }
      
        if (!capture.isOpened())//检测摄像头是否正常获取图像
        {        
            cout << "video failed" << endl;
            return 0;
        }

        if (!capture.read(img))
        {
            continue;
        }

        //[02] 图像预处理
        Mat imgBinary = preprocess.binaryzation(img); // 图像二值化
        Mat AIimg = img.clone();
        Mat Parameters(500, 300, CV_8UC3, cv::Scalar(255, 0, 0));
  
        //[03] 启动AI推理
        if(!future.valid())
        {
            future = std::async(std::launch::async, [&detection](const cv::Mat image) {detection->inference(image);}, AIimg);
        }

        if (future.wait_for(std::chrono::seconds(0)) == std::future_status::ready)
        {
            // 如果异步任务已经完成
            // 获取结果并处理
            AIFlag = true;
            future = std::async(std::launch::async, [&detection](const cv::Mat image) {detection->inference(image);}, AIimg);
        } 
        else 
        {
            AIFlag = false;
        }

        //临时参数设置
        centerType = CenterType::Mid; // 中线类型
        way=false;//起始点寻找方式
        if(catering.cateringEnable)
            way=true;
        else
            way=false;

        if(scene == Scene::LaybyScene)
        {
            // 2. 定义圆形结构元素（核）
            int kernel_size = 3; // 扩大程度，值越大黑点膨胀越大
            cv::Mat kernel = cv::getStructuringElement(
            cv::MORPH_ELLIPSE, 
            cv::Size(2 * kernel_size + 1, 2 * kernel_size + 1));
            cv::erode(imgBinary, imgBinary, kernel);
        }

        //[04] 赛道识别
        tracking.ClearDatas();
        preprocess.black_border(imgBinary);
        tracking.search(600,imgBinary,way);
        tracking.ProcessEdgesToSingleLine(tracking.pointsEdgeLeft,tracking.pointsEdgeRight);
        //tracking.track(imgBinary);

        //tracking.trackwidth();

        //[05] 停车区检测
        if (motion.params.parking)
        {
            if (parking.process(detection->results,motion.params.Parkingcount))
            {
                scene = Scene::StopScene;
                if (parking.countExit >1) 
                {
                    printf("-----> System Exit!!! <-----\n");
                    uart->carControl(0,PWMSERVOMID);
                    exit(0); // 程序退出
                }
            }
        }

        //[06] 快餐店检测
        if ((scene == Scene::NormalScene || scene == Scene::CateringScene) &&motion.params.catering)
        {
            if (catering.process(tracking,img,detection->results,motion.params.Cateringcount,motion.params.cateringPosion))  // 传入二值化图像进行再处理
                 scene = Scene::CateringScene;
            else
                scene = Scene::NormalScene;
           
            if(scene == Scene::CateringScene)
            {
                cout<<"快餐店"<<endl;
                motion.speed=motion.params.speedCatering;
                if(catering.burgerLeft)
                    centerType = CenterType::Right;
                else
                    centerType = CenterType::Left;

                if(catering.step==catering.Step::stop)
                {
                    motion.speed = 0;
                    uart->buzzerSound(uart->BUZZER_OK); 
                }
                
            }
       }
   
        //[07] 临时停车区检测
        if ((scene == Scene::NormalScene || scene == Scene::LaybyScene) &&motion.params.layby) 
        {
            if (layby.process(tracking,img,detection->results,motion.params.Laybycount,motion.params.laybyPosion))  
                scene = Scene::LaybyScene;
            else
                scene = Scene::NormalScene;

            if (scene == Scene::LaybyScene)
            {
                //cout<<"临时停车"<<endl;
                motion.speed = motion.params.speedLayby;
                if (layby.leftEnable)
                    centerType = CenterType::Left_Layby;
                else
                    centerType = CenterType::Right_Layby;

                //if (layby.step == layby.Step::init)
                //    uart->buzzerSound(uart->BUZZER_DING);

                if (layby.stopEnable)
                    motion.speed = 0;
            }
       }

        //[08] 充电停车场检测
        if ((scene == Scene::NormalScene || scene == Scene::ParkingScene) &&motion.params.charging)
        {
            if (charging.process(tracking,img,detection->results,motion.params.Chargingcount,motion.params.chargingPosion))  // 传入二值化图像进行再处理
                scene = Scene::ParkingScene;
            else
                scene = Scene::NormalScene;
           
            if (scene == Scene::ParkingScene)
            {
                //cout<<"充电区"<<endl;
                if(charging.ChargingLeft)
                    centerType = CenterType::Right;
                else
                    centerType = CenterType::Left;  
                
                motion.speed=motion.params.speedParking;
                if(charging.step == charging.Step::stop)
                    motion.speed = 0;
                else if (charging.step == charging.Step::trackout) // 倒车出库
                    motion.speed = -motion.params.speedDown; 
            }
                
        }
   
        //[09] 坡道区检测
        if ((scene == Scene::NormalScene || scene == Scene::BridgeScene) &&motion.params.bridge)
        {
            motion.speed = motion.params.speedBridge;
            if (bridge.process(tracking, detection->results,motion.params.Bridgecount))
                scene = Scene::BridgeScene;
            else
                scene = Scene::NormalScene;

            if (scene == Scene::BridgeScene)
            {
                //cout<<"坡道"<<endl;
                uart->buzzerSound(uart->BUZZER_DING);
            }
        }

        //[10] 障碍区检测
        if ((scene == Scene::NormalScene || scene == Scene::ObstacleScene) &&motion.params.obstacle)
        {
            if (obstacle.process(tracking,detection->results,img))  
                scene = Scene::ObstacleScene;
            else
                scene = Scene::NormalScene;

            if (scene == Scene::ObstacleScene)
            {
                //cout<<"障碍"<<endl;
                //误差
                if (obstacle.coneleft||obstacle.blockleft||obstacle.peopleleft)
                    centerType = CenterType::Right_Obstacle;
                if (obstacle.coneright||obstacle.blockright||obstacle.peopleright)
                    centerType = CenterType::Left_Obstacle;
                //速度
                if(obstacle.resultObs.type==LABEL_CONE)
                    motion.speed = motion.params.speedTone;
                else if(obstacle.resultObs.type==LABEL_BLOCK)
                    motion.speed = motion.params.speedBlock;
                else if(obstacle.resultObs.type==LABEL_PEDESTRIAN)
                    motion.speed = motion.params.speedPeople;
                uart->buzzerSound(uart->BUZZER_DING); // 祖传提示音效
            }
        }

        //[11] 环岛识别与路径规划
        if ((scene == Scene::NormalScene || scene == Scene::RingScene) &&
            motion.params.ring && !layby.noRing && !catering.noRing && !charging.noRing) 
        {
            if (ring.process(tracking, img,imgBinary))
                scene = Scene::RingScene;
            else
                scene = Scene::NormalScene;

            if (scene == Scene::RingScene)
            {
                //cout<<"环岛"<<endl;
                motion.speed = motion.params.speedRing;
                if (ring.ringType == ring.RingType::RingRight)
                {
                    if ((ring.ringStep == ring.RingStep::Entering) || (ring.ringStep == ring.RingStep::Finish))
                    {
                        centerType = CenterType::Left;
                        uart->buzzerSound(uart->BUZZER_OK);
                    }

                    if (ring.ringStep == ring.RingStep::Exiting)
                        centerType = CenterType::Right;
                }

                if (ring.ringType == ring.RingType::RingLeft)
                {
                    if ((ring.ringStep == ring.RingStep::Entering) || (ring.ringStep == ring.RingStep::Finish))
                    {
                        centerType = CenterType::Right;
                        uart->buzzerSound(uart->BUZZER_OK);
                    }

                    if (ring.ringStep == ring.RingStep::Exiting)
                        centerType = CenterType::Left; 
                }
            }
        }

        //[12] 十字道路识别与路径规划
        if (scene == Scene::NormalScene&&motion.params.cross)
        {
            if(crossroad.crossRecognition(tracking,img))
            {
                cout<<"十字"<<endl;
                uart->buzzerSound(uart->BUZZER_OK);
            }               
        }
        
        //[13] 车辆控制中心拟合
        ctrlCenter.fitting(tracking,centerType);

        if (scene != Scene::StopScene && scene != Scene::ParkingScene)
        {
            if (ctrlCenter.derailmentCheck(imgBinary)) // 车辆冲出赛道检测（保护车辆）
            {
                uart->buzzerSound(uart->BUZZER_WARNNING);
                uart->carControl(0, PWMSERVOMID); // 控制车辆停止运动
                sleep(1);
                printf("-----> 出界保护!!! <-----\n");
                exit(0); // 程序退出
            }
        }

        //[14] 运动控制(速度+方向)   
        int controlCenter=0;
        //前瞻
        if(bridge.bridgeEnable)
            controlCenter=ctrlCenter.centerEdge[10].x;
        else if(obstacle.enable)
            controlCenter=ctrlCenter.centerEdge[40].x;
        else
            controlCenter=ctrlCenter.centerEdge[motion.params.forword].x;

        //转向 
        if(scene == Scene::ObstacleScene)
        {
            if(obstacle.resultObs.type==LABEL_CONE)
            {
                motion.turnP=motion.params.ToneP;
                motion.turnD=motion.params.ToneD;
            }
            else if(obstacle.resultObs.type==LABEL_BLOCK)
            {
                motion.turnP=motion.params.BlockP;
                motion.turnD=motion.params.BlockD;
            }
            else if(obstacle.resultObs.type==LABEL_PEDESTRIAN)
            {
                motion.turnP=motion.params.PeopleP;
                motion.turnD=motion.params.PeopleD;
            }

        }
        else if(scene == Scene::RingScene)
        {
            if(ring.ringStep==ring.RingStep::Entering)
            {
                motion.turnP=motion.params.RingIP;
                motion.turnD=motion.params.RingID;
            }
            if(ring.ringStep==ring.RingStep::Exiting)
            {
                motion.turnP=motion.params.RingOP;
                motion.turnD=motion.params.RingOD;
            }

        }
        else if(scene == Scene::LaybyScene)
        {
            motion.turnP=motion.params.LaybyP;
            motion.turnD=motion.params.LaybyD;
        }
        else
        {
            motion.turnP=motion.params.turnP;
            motion.turnD=motion.params.turnD;
        }
        //cout<<motion.turnP<<endl;
        motion.poseCtrl(controlCenter); 

        if(charging.step==charging.Step::turning || charging.step==charging.Step::trackout|| charging.step==charging.Step::stop)
        {
            if(charging.ChargingLeft)
                motion.servoPwm=motion.params.LeftPWM;
            else
                motion.servoPwm=motion.params.RightPWM;
        }
           

        //速度
        if (scene == Scene::NormalScene)
        {
            if(Straight_Judge(tracking.edgeleft,0,100)<1&&Straight_Judge(tracking.edgeright,0,100)<1)
                motion.speed=motion.params.speedHigh;
            else
                motion.speed=motion.params.speedLow;//普通速度
        }

        //[串口发送    
        if(!motion.params.debug&&!motion.params.show) // 非调试模式下
            uart->carControl(motion.speed,motion.servoPwm);
        if(AIFlag)
            detection->drawBox(AIimg);
        if(motion.params.saveImg)
            savePicture(AIimg); 

        //[15] 综合显示调试UI窗口
        if (motion.params.show)
        {
            // 图像绘制AI结果
  
                
            //cvtColor(imgBinary, imgBinary, COLOR_GRAY2BGR); // RGB转灰度图
            // 图像绘制巡线结果
            //ctrlCenter.drawImage(tracking, imgBinary);
            //tracking.drawimg2(imgBinary);
            ctrlCenter.drawImage(tracking, img);
            tracking.drawimg2(img);
            line(img,Point(0,ctrlCenter.centerEdge[motion.params.forword].y),Point(319,ctrlCenter.centerEdge[motion.params.forword].y),Scalar(255,0,0),1);
            //tracking.drawimg1(img);
    
            putText(Parameters, "edgeleft_size:", Point(10, 10), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "edgeright_size:", Point(10, 30), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "EdgeLeft_size:", Point(10, 50), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "Edgeright_size:", Point(10, 70), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "leftlosenum:", Point(10, 90), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "rightlosenum:", Point(10, 110), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "controlCenter:", Point(10, 130), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "servoPwm:", Point(10, 150), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "FPS:", Point(10, 170), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "speed:", Point(10, 190), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "Topline:", Point(10, 210), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "stdevLeft:", Point(10, 230), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "stdevRight:", Point(10, 250), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "Scene:", Point(10, 270), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "bridge:", Point(10, 290), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "catering:", Point(10, 310), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "charging:", Point(10, 330), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "layby:", Point(10, 350), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "obstacle:", Point(10, 370), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "parking:", Point(10, 390), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "ring:", Point(10, 410), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "leftstraight:", Point(10, 430), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, "rightstraight:", Point(10, 450), 1, 1, cv::Scalar(0, 255, 0));

            string intText0 = to_string(tracking.edgeLeft_Size);
            string intText1 = to_string(tracking.edgeRight_Size);
            string intText2 = to_string(tracking.pointsEdgeLeft.size());
            string intText3 = to_string(tracking.pointsEdgeRight.size());
            string intText4 = to_string(tracking.leftlosenum);
            string intText5 = to_string(tracking.rightlosenum);
            string intText6 = to_string(controlCenter);
            string intText7 = to_string(motion.servoPwm);
            string intText8 = to_string((int)detFPS);
            string intText9 = to_string((int)motion.speed);
            string intText10 = to_string(tracking.topline);
            string intText11 = to_string((int)tracking.stdevLeft);
            string intText12 = to_string((int)tracking.stdevRight);
            string intText13 = getScene(scene);
            string intText14 = to_string(bridge.bridgeEnable);
            string intText15 = to_string(catering.step);
            string intText16 = to_string(charging.step);
            string intText17 = to_string(layby.step);
            string intText18 = to_string(obstacle.enable);
            string intText19 = to_string(parking.step);
            string intText20 = to_string(ring.ringStep);
            string intText21 = to_string(Straight_Judge(tracking.edgeleft,10,100));
            string intText22 = to_string(Straight_Judge(tracking.edgeright,10,100));

            putText(Parameters, intText0, Point(150, 10), 1, 1, cv::Scalar(0, 255, 0));    
            putText(Parameters, intText1, Point(150, 30), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText2, Point(150, 50), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText3, Point(150, 70), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText4, Point(150, 90), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText5, Point(150, 110), 1, 1, cv::Scalar(0, 255, 0));    
            putText(Parameters, intText6, Point(150, 130), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText7, Point(150, 150), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText8, Point(150, 170), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText9, Point(150, 190), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText10, Point(150, 210), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText11, Point(150, 230), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText12, Point(150, 250), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText13, Point(150, 270), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText14, Point(150, 290), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText15, Point(150, 310), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText16, Point(150, 330), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText17, Point(150, 350), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText18, Point(150, 370), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText19, Point(150, 390), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText20, Point(150, 410), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText21, Point(150, 430), 1, 1, cv::Scalar(0, 255, 0));
            putText(Parameters, intText22, Point(150, 450), 1, 1, cv::Scalar(0, 255, 0));
 
            //图像显示
            imshow("原图",img);
            //imshow("AI",AIimg);
            imshow("灰度",imgBinary);
            imshow("参数",Parameters);  

            waitKey(1);
        }

        //[16] 按键退出程序
        if (uart->keypress)
        {
            uart->carControl(0, PWMSERVOMID); // 控制车辆停止运动
            sleep(1);
            printf("-----> System Exit!!! <-----\n");
            exit(0); // 程序退出
        }    
    }

    uart->close(); // 串口通信关闭
    capture.release();
    return 0;
}