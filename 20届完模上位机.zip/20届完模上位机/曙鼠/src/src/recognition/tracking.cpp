#pragma once

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <unordered_map>
#include <algorithm>
#include "../detection/parking.cpp"     //AI检测：停车区

using namespace cv;
using namespace std;

class Tracking
{
public:
	/**
     * @brief 清除历史数据
     */
    void ClearDatas();

	/**
     * @brief 寻找左右起始点
     * @param Binaryimg 输入二值化图像
     * @return find_Boundary_flag	起始点标志位
     */
    int Find_Boundary(Mat& Binaryimg,bool way);

    /**
     * @brief 边界搜索
     * @param break_flag 边线循环次数
     * @param Binaryimg	输入二值化图像
     */
    void search(int break_flag, Mat &Binaryimg,bool way);

    /**
     * @brief 边界提取
     */
    void ProcessEdgesToSingleLine(vector<Point> pointsEdgeLeft,vector<Point> pointsEdgeRight);

    /**
     * @brief 赛道宽度计算
     */
    void trackwidth();

    /**
     * @brief 边缘方差计算
     * @param v_edge
     * @param img_height
     * @return double
     */
    double stdevEdgeCal(vector<Point> &v_edge, int img_height);

    //长白列
    void track(Mat &Binaryimg);

    //环岛二次扫线
    void tracking(Mat& Binaryimg,Point L,Point R,int stop);
    /**
     * @brief 绘制边界及中线
     * @param img 输入图像
     */
    void drawimg1(Mat &img);

    /**
     * @brief 绘制边界及中线
     * @param img 输入图像
     */
    void drawimg2(Mat &img);

	vector<Point> pointsEdgeLeft;     // 赛道左边缘点集
	vector<Point> pointsEdgeRight;    // 赛道右边缘点集
    vector<Point> edgeleft;      // 赛道左边缘点集
	vector<Point> edgeright;    // 赛道右边缘点集
    double stdevLeft;                 // 边缘斜率方差（左）
    double stdevRight;                // 边缘斜率方差（右）
    vector<int> Left_lose_judge;
    vector<int> Right_lose_judge;
    vector<int> Width;
    int edgeLeft_Size;
    int edgeRight_Size;
    int leftlosenum = 0;//左边丢线数
    int rightlosenum = 0;//右边丢线数
    int topline =0;
    int rowCutUp=60;
    int rowCutBottom=60;

    //长白列
    vector<int> White_Column;
    int LongWhite = 0;
    int Cols = 0;

private:
    bool left_found;                    //左邻域循环标志位
    bool right_found;                   //右邻域循环标志位
	uint16_t rows = 199;                // 图像行数
	uint16_t cols = 320;                // 图像列数
	int find_Boundary_flag = 0;         // 找到左右起始点标志位
	int mid=cols/2;
};

/******************************************************START******************************************************/
/**
 * @brief 清除历史数据
 */
void Tracking::ClearDatas()
{
	pointsEdgeLeft.clear();
	pointsEdgeRight.clear();
    edgeleft.clear();
    edgeright.clear();
    Left_lose_judge.clear();
    Right_lose_judge.clear();
    Width.clear();
    stdevLeft = 0;                 
    stdevRight = 0;               
    leftlosenum = 0;
    rightlosenum = 0;

    //长白列
    White_Column.clear();
    LongWhite = 0;
    Cols = 0;
}

/**
 * @brief 寻找左右起始点
 * @param Binaryimg 输入二值化图像
 * @return find_Boundary_flag	起始点标志位
 */
int Tracking::Find_Boundary(Mat& Binaryimg,bool way)
{
    find_Boundary_flag = 0;
    
    if(way)//两边向中间搜索
    {
        // 左起始点搜索
        for (int m = 1; m < 160; m++)
        {
            if (Binaryimg.at<uchar>(rows , m - 1) == 0 && 
                Binaryimg.at<uchar>(rows , m) == 255 &&
                Binaryimg.at<uchar>(rows , m + 1) == 255)
            {
                pointsEdgeLeft.push_back(Point(m, rows));
                find_Boundary_flag++;
                break;
            }

        }

        // 右起始点搜索
        for (int n = 318; n > 160; n--)
        {
            if (Binaryimg.at<uchar>(rows , n - 1) == 255 &&
                Binaryimg.at<uchar>(rows , n) == 255 &&
                Binaryimg.at<uchar>(rows , n + 1) == 0)
            {
                pointsEdgeRight.push_back(Point(n, rows));
                find_Boundary_flag++;
                break;
            }

        }

    }
    else//中间向两边搜索
    {
        // 左起始点搜索
        for (int m = mid; m >= 0; m--)
        {
            if (Binaryimg.at<uchar>(rows , m) == 0 && 
                Binaryimg.at<uchar>(rows , m + 1) == 255&&
                Binaryimg.at<uchar>(rows , m + 2) == 255)
            {
                pointsEdgeLeft.push_back(Point(m, rows));
                find_Boundary_flag++;
                break;
            }
        }
        
        // 右起始点搜索
        for (int n = mid; n < cols; n++)
        {
            if (Binaryimg.at<uchar>(rows , n) == 0 &&
                Binaryimg.at<uchar>(rows , n - 1) == 255&&
                Binaryimg.at<uchar>(rows , n - 2) == 255)
            {
                pointsEdgeRight.push_back(Point(n, rows));
                find_Boundary_flag++;
                break;
            }
        }
    }
      
    if(find_Boundary_flag == 2) 
    {
        mid = (int)(pointsEdgeLeft[0].x + pointsEdgeRight[0].x)/2;
    }
         
    return find_Boundary_flag;
}

/**
 * @brief 边界搜索
 * @param break_flag 边线循环次数
 * @param Binaryimg	输入二值化图像
 */
void Tracking::search(int break_flag, Mat& Binaryimg,bool way)
{
    if (Find_Boundary(Binaryimg,way) == 2)
    {
        int left = 0;//统计左边总共的长度
        int right = 0;//统计右边总共的长度

        //定义八个邻域
        vector<Point> seeds_left =
        {
              { -1, 1 }, { 0, 1 }, { 1, 1 },
              { 1, 0 },            { 1, -1 },
              { 0, -1 },{ -1, -1 },{ -1, 0 }
        };
        //{-1,-1},{0,-1},{+1,-1},6 5 4      这个是逆时针
        //{-1, 0},       {+1, 0},7   3
        //{-1,+1},{0,+1},{+1,+1},0 1 2

        vector<Point> seeds_right =
        {
            {1, 1},{0,1},{-1,1},
            {-1,0},      {-1,-1},
            {0,-1},{1,-1},{1,0},
        };
        //{-1,-1},{0,-1},{+1,-1},4 5 6       这个是顺时针
        //{-1, 0},       {+1, 0},3   7
        //{-1,+1},{0,+1},{+1,+1},2 1 0

        int direction_left = 3;//左边线的方向  0-7
        int direction_right = 3;//右边线的方向  0-7

        bool should_break = false;

        //开启邻域循环
        for (; break_flag > 0; break_flag--)//最大循环次数
        {
            //搜索左边线
            if(pointsEdgeLeft[left].y >= pointsEdgeRight[right].y&&pointsEdgeLeft[left].y>59)
            {
            for (int j = 0; j < 8; j++)
            {
                if (direction_left < 0) { direction_left += 8; }
                else if (direction_left >= 8) { direction_left -= 8; }
                Point serch_filds = { 0,0 };
                serch_filds.x = pointsEdgeLeft[left].x + seeds_left[direction_left].x;
                serch_filds.y = pointsEdgeLeft[left].y + seeds_left[direction_left].y;

                if (Binaryimg.at<uchar>(serch_filds) == 0)//黑
                {
                    topline=serch_filds.y;
                    pointsEdgeLeft.push_back(serch_filds);
                    left++;
                    direction_left -= 2;  //如果找到黑色的点 就会改变他的方向
                    // 检查相遇条件
                    if (!pointsEdgeRight.empty() && 
                        pointsEdgeLeft.back() == pointsEdgeRight.back())
                    {
                        should_break = true;
                    }                 
                    break;
                }
                direction_left++;  //不是黑色 方向加1
            }
                if (should_break) break;
            }
            //搜索右边线
            if(pointsEdgeRight[right].y >= pointsEdgeLeft[left-1].y&&pointsEdgeRight[right].y>59)
            {
            for (int j = 0; j < 8; j++)
            {
                if (direction_right < 0) { direction_right += 8; }
                else if (direction_right >= 8) { direction_right -= 8; }
                Point serch_filds = { 0,0 };
                serch_filds.x = pointsEdgeRight[right].x + seeds_right[direction_right].x;
                serch_filds.y = pointsEdgeRight[right].y + seeds_right[direction_right].y;

                if (Binaryimg.at<uchar>(serch_filds) == 0)//黑
                {
                    pointsEdgeRight.push_back(serch_filds);
                    right++;
                    direction_right -= 2;  //如果找到黑色的点 就会改变他的方向
                    // 检查相遇条件
                    if (!pointsEdgeLeft.empty() && 
                        pointsEdgeRight.back() == pointsEdgeLeft.back())
                    {
                        should_break = true;
                    }
                    break;
                }
                direction_right++;  //不是黑色 方向加1
            }
                if (should_break) break;
            }

            if (should_break) break;
        }
    }
}


void Tracking::ProcessEdgesToSingleLine(vector<Point> pointsEdgeLeft,vector<Point> pointsEdgeRight) 
{
    // 处理右侧点，每行取最左边的点（x最小），且Y <= 200
    unordered_map<int, int> rightMap; // key: y, value: 最小x
    for (const Point& pt : pointsEdgeRight) {
        int y = pt.y;
        if (y > 199) continue; // 新增：跳过Y大于200的点
        int x = pt.x;
        if (rightMap.find(y) == rightMap.end()) {
            rightMap[y] = x;
        } else {
            if (x < rightMap[y]) rightMap[y] = x;
        }
    }

    // 提取y并降序排序（仅保留Y <= 200的点）
    vector<int> rightYs;
    for (const auto& pair : rightMap) {
        rightYs.push_back(pair.first);
    }
    sort(rightYs.begin(), rightYs.end(), greater<int>());

    // 生成edgeright
    edgeright.clear();
    for (int y : rightYs) {
        edgeright.emplace_back(rightMap[y], y);
    }

    // 处理左侧点，每行取最右边的点（x最大），且Y <= 200
    unordered_map<int, int> leftMap; // key: y, value: 最大x
    for (const Point& pt : pointsEdgeLeft) {
        int y = pt.y;
        if (y > 199) continue; // 新增：跳过Y大于200的点
        int x = pt.x;
        if (leftMap.find(y) == leftMap.end()) {
            leftMap[y] = x;
        } else {
            if (x > leftMap[y]) leftMap[y] = x;
        }
    }

    // 提取y并降序排序（仅保留Y <= 200的点）
    vector<int> leftYs;
    for (const auto& pair : leftMap) {
        leftYs.push_back(pair.first);
    }
    sort(leftYs.begin(), leftYs.end(), greater<int>());

    // 生成edgeleft
    edgeleft.clear();
    for (int y : leftYs) {
        edgeleft.emplace_back(leftMap[y], y);
    }

    if(edgeleft.size()==141&&edgeright.size()==141)
    {
        edgeleft.resize(140);
        edgeright.resize(140);
    }
    //赛道信息
    for (int i = 0; i < edgeleft.size(); i++)
    {
        //左边线
        if(edgeleft[i].x==0)
        {
            leftlosenum++;
            Left_lose_judge.push_back(1);
        }
        else
        {
            Left_lose_judge.push_back(0);
        }
        //右边线
        if(edgeright[i].x==319)
        {
            rightlosenum++;
            Right_lose_judge.push_back(1);
        } 
        else
        {
            Right_lose_judge.push_back(0);
        }
        //赛道宽度
        Width.push_back(edgeright[i].x-edgeleft[i].x);
        //cout<<"第"<<i<<"行宽度:"<<Width[i]<<endl;
    }

    edgeLeft_Size=edgeleft.size();
    edgeRight_Size=edgeright.size();
    stdevLeft = stdevEdgeCal(edgeleft, ROWSIMAGE); // 计算边缘方差
    stdevRight = stdevEdgeCal(edgeright, ROWSIMAGE);
}

/**
 * @brief 赛道宽度计算
 */
void Tracking::trackwidth()
{
    cout<<"-----开始-------"<<endl;
    for(int i=0;i<edgeleft.size();i++)
    { 
        int width;
        width=track_judgment(edgeleft,edgeright,i);
        //cout<<"第"<<i<<"行宽度:"<<width<<endl;
        cout<<width<<","<<endl;
    }
    cout<<"-----结束-------"<<endl;
}

/**
 * @brief 绘制边界及中线
 * @param img 输入图像
 */
void Tracking::drawimg1(Mat &img)
{
    for (int n = 0; n < pointsEdgeRight.size(); n++)
    {
        circle(img, pointsEdgeRight[n], 1, Scalar(0,255,0), FILLED);
    }   
    for (int n = 0; n < pointsEdgeLeft.size(); n+=3)
    {
        circle(img, pointsEdgeLeft[n], 1, Scalar(255,0,0), FILLED);
    }    
}

/**
 * @brief 边缘方差计算
 * @param v_edge
 * @param img_height
 * @return double
 */
double Tracking::stdevEdgeCal(vector<Point> &v_edge, int img_height)
{
    if (v_edge.size() < static_cast<size_t>(img_height / 8)) {
      return 1000;
    }
    vector<int> v_slope;
    int step = 10; // v_edge.size()/10;
    for (size_t i = step; i < v_edge.size(); i += step) {
      if (v_edge[i].x - v_edge[i - step].x)
        v_slope.push_back((v_edge[i].y - v_edge[i - step].y) * 100 /
                          (v_edge[i].x - v_edge[i - step].x));
    }
    if (v_slope.size() > 1) {
      double sum = accumulate(begin(v_slope), end(v_slope), 0.0);
      double mean = sum / v_slope.size(); // 均值
      double accum = 0.0;
      for_each(begin(v_slope), end(v_slope),
               [&](const double d) { accum += (d - mean) * (d - mean); });

      return sqrt(accum / (v_slope.size() - 1)); // 方差
    } else
      return 0;
}

/**
 * @brief 绘制边界及中线
 * @param img 输入图像
 */
void Tracking::drawimg2(Mat &img)
{
    for (int n = 0; n < edgeleft.size(); n++)
    {
        circle(img, edgeleft[n], 1, Scalar(255,0,0), 1);
    }    
    for (int n = 0; n < edgeright.size(); n++)
    {
        circle(img, edgeright[n], 1, Scalar(255,0,0), 1);
    }     
}
/*******************************************************END*******************************************************/

void Tracking::track(Mat &Binaryimg)
{
    //从左到右，从下往上，遍历全图记录范围内的每一列白点数量
    for (int j =1; j<319; j++)
    {
        int white =0;
        for (int i = 199; i >= 60; i--)
        {
            if(Binaryimg.at<uchar>(i , j) == 0)
                break;
            else
                white++;
        }
        White_Column.push_back(white);
    }

    //最长白列
    for(int i=0;i< White_Column.size();i++)
    {
        if (LongWhite < White_Column[i])//找最长的那一列
        {
            LongWhite = White_Column[i];//白列长度
            Cols = i+1;              //是下标，第j列
        }
    }

    //最长白列左右巡线

    for (int i = 199; i >=60; i--)//常规巡线
    {
        for (int j = Cols; j <= 318; j++)
        {
            if (Binaryimg.at<uchar>(i , j+1) == 0 && 
                Binaryimg.at<uchar>(i , j) == 255 )
            {
                edgeright.push_back(Point(j+1,i));
                break;
            }

        }

        for (int j = Cols; j >= 0 ; j--)//往左边扫描
        {
            if (Binaryimg.at<uchar>(i , j-1) == 0 && 
                Binaryimg.at<uchar>(i , j) == 255)
            {
                edgeleft.push_back(Point(j-1,i));
                break;
            }
        }
    }
}


/**
 * @brief 边界搜索
 * @param break_flag 边线循环次数
 * @param Binaryimg	输入二值化图像
 */
void Tracking::tracking(Mat& Binaryimg,Point L,Point R,int stop)
{
    int mid=int((L.x+R.x)/2);
    int m,n;
   
    for(int i=R.y-1;i>stop+5;i--)
    {
        for(int j=mid;j>0;j--)
        {
            if (Binaryimg.at<uchar>(i , j-1) == 0 && 
                Binaryimg.at<uchar>(i , j) == 255)
            {
                edgeleft.push_back(Point(j-1,i));
                m=j;
                break;
            }
        }

        for(int j=mid;j<319;j++)
        {
            if (Binaryimg.at<uchar>(i , j+1) == 0 && 
                Binaryimg.at<uchar>(i , j) == 255 )
            {
                edgeright.push_back(Point(j+1,i));
                n=j;
                break;
            }
        }

        mid=int((m+n)/2);
    }
}