#pragma once

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../../include/common.hpp"
#include "tracking.cpp"


using namespace cv;
using namespace std;

class Crossroad
{
public:
    /**
     * @brief 初始化
     *
     */
    void reset(void)
    {
        //crossroadType = CrossroadType::None; // 十字道路类型
        left_up = 0, left_stage=0;
        left_down = 0, left_down_1=0;
        right_up = 0, right_stage=0;
        right_down = 0, right_down_1=0;
    }

    /**
     * @brief 十字道路识别与图像处理
     * @param track 赛道识别结果
     * @param imagePath 输入图像
     */
    bool crossRecognition(Tracking &track, Mat &img)
    {       
        //复位 
        reset();

        //寻找角点
        Searchleft(track,img);
        Searchright(track,img);

        //太近舍去
        if (abs(track.edgeleft[left_up].y - track.edgeleft[left_down].y) < 10) left_up = 0;
        if (abs(track.edgeright[right_up].y - track.edgeright[right_down].y) < 10) right_up = 0;

        //处理
        Left_deal(track);
        Right_deal(track);

        return left_up || left_down || right_up || right_down;
    }

//private:
    Point pointBreakLU;
    Point pointBreakLD;
    Point pointBreakRU;
    Point pointBreakRD;

    int left_up = 0, left_stage=0;
    int left_down = 0, left_down_1=0;
    int right_up = 0, right_stage=0;
    int right_down = 0, right_down_1=0;

    /**
     * @brief 十字道路类型
     *
     */
    enum CrossroadType
    {
        None = 0,
        CrossroadLeft,     // 左斜入十字
        CrossroadRight,    // 右斜入十字
        CrossroadStraight, // 直入十字
    };

    CrossroadType crossroadType = CrossroadType::None; // 十字道路类型

    void Searchleft(Tracking &track,Mat &img)
    {
        if(track.edgeleft.size()>20&&track.leftlosenum>20&&track.rightlosenum>20)
        {
            for (int i = 10; i < track.edgeleft.size() - 10; i ++)
            {
            //下角点
            if (track.edgeleft[i].x - track.edgeleft[i - 5].x <= -20 &&
                track.edgeleft[i - 5].x >= track.edgeleft[i - 10].x)
            {
                if (left_down == 0)
                    left_down = i - 5;
                else if (track.edgeleft[i - 5].x > track.edgeleft[left_down].x && abs(track.pointsEdgeLeft[i - 5].y - track.pointsEdgeLeft[left_down].y) < 10)
                    left_down = i - 5;
            }

            if (2 * track.edgeleft[i - 5].x - track.edgeleft[i].x - track.edgeleft[i - 10].x >= 10 &&
                track.edgeleft[i - 5].x - track.edgeleft[i].x >= 2 &&
                track.edgeleft[i - 5].x - track.edgeleft[i - 10].x >= 2)
            {
                if (left_down == 0)
                    left_down = i - 5;
                else if (track.edgeleft[i - 5].x > track.edgeleft[left_down].x && abs(track.edgeleft[i - 5].y - track.edgeleft[left_down].y) < 10)
                    left_down = i - 5;
            }

            //上角点
            if (track.edgeleft[i-4].x - track.edgeleft[i - 5].x >= -3 &&
                track.edgeleft[i-4].x - track.edgeleft[i - 5].x <= 3&&
                track.edgeleft[i - 5].x - track.edgeleft[i - 10].x >= 20)
            {
                if (left_up == 0)
                    left_up = i - 5;
                else if (track.edgeleft[i].x > track.edgeleft[left_up].x)
                    left_up = i - 5;
            }

        }

        if(left_down!=0)
            circle(img,track.edgeleft[left_down],5,Scalar(0,255,0),FILLED);
        if(left_up!=0)    
            circle(img,track.edgeleft[left_up],5,Scalar(0,255,0),FILLED);
        }
    }

    void Searchright(Tracking &track,Mat &img)
    {
        if(track.edgeright.size()>20&&track.rightlosenum>20&&track.leftlosenum>20)
        {
            for (int i = 10; i < track.edgeright.size() - 10; i ++)
            {
                if (track.edgeright[i].x - track.edgeright[i - 5].x >= 20 &&
                    track.edgeright[i - 5].y <= track.edgeright[i - 10].y)
                    {
                        if (right_down == 0)
                            right_down = i - 5;
                        else if (track.edgeright[i - 5].x < track.edgeright[right_down].x && abs(track.edgeright[i - 5].y - track.edgeright[right_down].y) < 10)
                            right_down = i - 5;
                    }
                
                if (2 * track.edgeright[i - 5].x - track.edgeright[i].x - track.edgeright[i - 10].x <= -10 &&
                    track.edgeright[i - 5].x - track.edgeright[i].x <= -2 &&
                    track.edgeright[i - 5].x - track.edgeright[i - 10].x <= -2)
                {
                    if (right_down == 0)
                        right_down = i - 5;
                    else if (track.edgeright[i - 5].x < track.edgeright[right_down].x && abs(track.edgeright[i - 5].y - track.edgeright[right_down].y) < 10)
                        right_down = i - 5;
                }

                if (track.edgeright[i-4].x - track.edgeright[i - 5].x <=3 &&
                    track.edgeright[i-4].x - track.edgeright[i - 5].x >= -3 &&
                    track.edgeright[i - 5].x - track.edgeright[i - 10].x <= -20)
                {
                    if (right_up == 0)
                        right_up = i - 5;
                    else if (track.edgeright[i].x < track.edgeright[right_up].x)
                        right_up = i - 5;
                }
            }

            if(right_down!=0)
                circle(img,track.edgeright[right_down],5,Scalar(0,255,0),FILLED);
            if(right_up!=0) 
                circle(img,track.edgeright[right_up],5,Scalar(0,255,0),FILLED);
        }

    }

    void Left_deal(Tracking &track)
    {
        if (left_down != 0 && left_up != 0 && track.edgeleft[left_up].y < track.edgeleft[left_down].y)
        {
            if (track.edgeleft[left_down].y != track.edgeleft[left_up].y)
            {
                int temp_x;
                for (int i = left_down + 1; i < left_up; i ++)
                {
                    temp_x = track.edgeleft[left_down].x +
                        (track.edgeleft[left_down].y - track.edgeleft[i].y) *
                        (track.edgeleft[left_up].x - track.edgeleft[left_down].x) /
                        (track.edgeleft[left_down].y - track.edgeleft[left_up].y);

                    if (temp_x < 0)
                        track.edgeleft[i].x = 0;
                    else if (temp_x >= COLSIMAGE)
                        track.edgeleft[i].x = COLSIMAGE - 1;
                    else 
                        track.edgeleft[i].x = temp_x;
                }
            }
        }
        else
        {
            if (left_down != 0)
            {
                uint8_t left_begin = left_down > 20 ? left_down - 20 : 0;
                while (abs(track.edgeleft[left_begin].x - track.edgeleft[left_down].x) > 10 &&
                       left_begin < left_down - 10) left_begin ++;
                if (track.edgeleft[left_begin].y != track.edgeleft[left_down].y)
                {
                    int temp_x;
                    for (int i = left_down + 1; i < track.edgeleft.size(); i ++)
                    {
                        temp_x = track.edgeleft[left_down].x +
                            (track.edgeleft[left_down].y - track.edgeleft[i].y) *
                            (track.edgeleft[left_down].x - track.edgeleft[left_begin].x) /
                            (track.edgeleft[left_begin].y - track.edgeleft[left_down].y);
                        if (temp_x < 0) track.edgeleft[i].x = 0;
                        else if (temp_x >= COLSIMAGE) track.edgeleft[i].x = COLSIMAGE - 1;
                        else track.edgeleft[i].x = temp_x;
                    }
                }
            }
            if (left_up != 0)
            {
                uint8_t left_end = left_up + 20 < track.edgeleft.size() - 1 ? left_up + 20 : track.edgeleft.size() - 1;
                while (abs(track.edgeleft[left_end].x - track.edgeleft[left_up].x) > 10 &&
                       left_end > left_up + 10) left_end --;
                if (track.edgeleft[left_up].y != track.edgeleft[left_end].y)
                {
                    int temp_x;
                    for (int i = left_up - 1; i >= 0; i --)
                    {
                        temp_x = track.edgeleft[left_up].x -
                            (track.edgeleft[i].y - track.edgeleft[left_up].y) *
                            (track.edgeleft[left_end].x - track.edgeleft[left_up].x) /
                            (track.edgeleft[left_up].y - track.edgeleft[left_end].y);
                        if (temp_x < 0) track.edgeleft[i].x = 0;
                        else if (temp_x >= COLSIMAGE) track.edgeleft[i].x = COLSIMAGE - 1;
                        else track.edgeleft[i].x = temp_x;
                    }
                }
            }
        }
    }

    void Right_deal(Tracking &track)
    {
        if (right_down != 0 && right_up != 0 && track.edgeright[right_up].y < track.edgeright[right_down].y)
        {
            if (track.edgeright[right_down].y != track.edgeright[right_up].y)
            {
                int temp_x;
                for (int i = right_down + 1; i < right_up; i ++)
                {
                    temp_x = track.edgeright[right_down].x +
                        (track.edgeright[right_down].y - track.edgeright[i].y) *
                        (track.edgeright[right_up].x - track.edgeright[right_down].x) /
                        (track.edgeright[right_down].y - track.edgeright[right_up].y);

                    if (temp_x < 0)
                        track.edgeright[i].x = 0;
                    else if (temp_x >= COLSIMAGE)
                        track.edgeright[i].x = COLSIMAGE - 1;
                    else 
                        track.edgeright[i].x = temp_x;
                }
            }
        }
        else
        {
            if (right_down != 0)
            {
                uint8_t right_begin = right_down > 20 ? right_down - 20 : 0;
                while (abs(track.edgeright[right_begin].x - track.edgeright[right_down].x) > 10 &&
                       right_begin < right_down - 10) right_begin ++;
                         int temp_x;
                        for (int i = right_down + 1; i < track.edgeright.size(); i ++)
                        {
                            temp_x = track.edgeright[right_down].x +
                                (track.edgeright[right_down].y - track.edgeright[i].y) *
                                (track.edgeright[right_down].x - track.edgeright[right_begin].x) /
                                (track.edgeright[right_begin].y - track.edgeright[right_down].y);
                            if (temp_x < 0) track.edgeright[i].x = 0;
                            else if (temp_x >= COLSIMAGE) track.edgeright[i].x = COLSIMAGE - 1;
                            else track.edgeright[i].x = temp_x;
                        }
            }
        
            if (right_up != 0)
            {
                uint8_t right_end = right_up + 20 < track.edgeright.size() - 1 ? right_up + 20 : track.edgeright.size() - 1;
                while (abs(track.edgeright[right_end].x - track.edgeright[right_up].x) > 10 &&
                       right_end > right_up + 10) right_end --;
                        int temp_x;
                        for (int i = right_up - 1; i >= 0; i --)
                        {
                            temp_x = track.edgeright[right_up].x -
                                (track.edgeright[i].y - track.edgeright[right_up].y) *
                                (track.edgeright[right_end].x - track.edgeright[right_up].x) /
                                (track.edgeright[right_up].y - track.edgeright[right_end].y);
                            if (temp_x < 0) track.edgeright[i].x = 0;
                            else if (temp_x >= COLSIMAGE) track.edgeright[i].x = COLSIMAGE - 1;
                            else track.edgeright[i].x = temp_x;
                        }        
            }
        }
    }
       
};

