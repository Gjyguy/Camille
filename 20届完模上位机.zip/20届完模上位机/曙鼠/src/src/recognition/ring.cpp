#pragma once
/**
 * @file ring.cpp
 * @brief 环岛识别（基于track赛道识别后）
 * @note  环岛识别步骤（ringStep）：
 *          1：环岛识别（初始化）
 *          2：入环处理
 *          3：环中处理
 *          4：出环处理
 *          5：出环结束
 */

#include "../../include/common.hpp"
#include "tracking.cpp"
#include <cmath>
#include <fstream>
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

class Ring 
{
public: 
      /**
       * @brief 环岛识别初始化|复位
       *
       */
      void reset(void) 
      {
        ringType = RingType::RingNone; // 环岛类型
        ringStep = RingStep::None;     // 环岛处理阶段
        ringEnable = false;     
      }

      enum RingType {
        RingNone = 0, // 未知类型
        RingLeft,     // 左入环岛
        RingRight     // 右入环岛
      };
    
    
      /**
       * @brief 环岛运行步骤/阶段
       *
       */
      enum RingStep {
        None = 0, // 未知类型
        Entering, // 入环
        Inside,   // 环中
        Exiting,  // 出环
        Finish,    // 环任务结束
        Terminate
      };

      /**
       * @brief 环岛识别与行径规划
       *
       * @param track 基础赛道识别结果
       * @param imagePath 赛道路径图像
       */    
      bool process(Tracking &track, Mat &imagePath,Mat& Binaryimg) 
      {
        // [1] 环岛识别
        if(ringType == RingType::RingNone) 
        {
            // 环岛方向判定
            //[1]左环正常识别 
            if (Straight_Judge(track.edgeright,10,130)<1
                &&LsearchBreakLeftDown(track.pointsEdgeLeft,track.edgeleft)
                &&track.rightlosenum<10
                &&track.leftlosenum>30) 
            {
                ringType = RingType::RingLeft;
                ringStep = RingStep::Entering;
                ringEnable=true;
                circle(imagePath,pointBreakLD, 5, Scalar(0,0,255), FILLED);
                cout<<"左环1"<<endl;
            }
            //[2]左环弯接环识别
            else
            {
              uint8_t left_cnt = 0;  //判断增减趋势
              uint8_t left_state = 0;  //0:增, 1:减
              int cnt[3]={0,0,0};
              for (int i = 2; i < track.edgeleft.size(); i ++)
              {
                if(left_state==0)
                {
                  if (track.edgeleft[i].x == 0)  //丢线
                  {
                    cnt[0] ++; //25
                  }
                  if(track.edgeleft[i-2].x <= 3 && track.edgeleft[i].x <= 20 && track.edgeleft[i].x > 3) {left_state++;}
                }
                else if(left_state==1)
                {
                  if (track.edgeleft[i].x > track.edgeleft[i - 2].x)  //左边线向中间增
                  {
                    cnt[1] ++; //5
                  }
                  if(track.edgeleft[i].x < track.edgeleft[i-2].x ) {left_state++;}
                }
                else if(left_state==2)
                {
                  if (track.edgeleft[i].x < track.edgeleft[i-2].x)  //左边线向中间增
                  {
                    cnt[2] ++;
                  }
                }
                //cout<<"丢线"<<cnt[0]<<"递增"<<cnt[1]<<"递减"<<cnt[2]<<endl;

                if((cnt[0]>50&& cnt[1]>10 && cnt[1]<45 && cnt[2]>5&&Straight_Judge(track.edgeright,10,130)<1)&&track.rightlosenum<10)
                {
                  cout<<"左环2"<<endl;
                  ringType = RingType::RingLeft;
                  ringStep = RingStep::Entering;
                  ringEnable=true;
                  break;
                }
               
            }
                
          }
            //[1]右环正常识别 
            if(Straight_Judge(track.edgeleft,10,130)<1
               &&RsearchBreakRightDown(track.pointsEdgeRight,track.edgeright)
               &&track.leftlosenum<10
               &&track.rightlosenum>30)
            {
              ringType = RingType::RingRight;
              ringStep = RingStep::Entering;
              ringEnable=true;
              circle(imagePath,pointBreakRD, 5, Scalar(0,0,255), FILLED);
              cout<<"右环1"<<endl;
            }
            //[2]右环弯接环识别
            else
            {
              uint8_t right_cnt = 0;
              uint8_t right_state = 0;
              int cnt[3]={0,0,0};
              for (int i = 2; i < track.edgeright.size(); i ++)
              {
                if(right_state==0)
                {
                  if (track.edgeright[i].x == 319)  //丢线
                  {
                    cnt[0] ++;
                  }
                  if(track.edgeright[i].x == 319 && track.edgeright[i].x >= COLSIMAGE-20 && track.edgeright[i].x < COLSIMAGE-3) {right_state++;}
                }
                else if(right_state==1)
                {
                  if (track.edgeright[i].x < track.edgeright[i-2].x)  //右边线向中间增
                  {
                    cnt[1] ++; 
                  }
                  if(track.edgeright[i].x > track.edgeright[i-2].x) {right_state++;}
                }
                else if(right_state==2)
                {
                   if (track.edgeright[i].x > track.edgeright[i-2].x)  //右边线向右边减
                  {
                    cnt[2] ++;
                  }
                }
                
              }
              

                if((cnt[0]>50 &&cnt[1]>10 && cnt[1]<45 && cnt[2]>5&&track.stdevRight<70&&Straight_Judge(track.edgeleft,10,130)<1)&&track.leftlosenum<10)
                {
                  ringType = RingType::RingRight;
                  ringStep = RingStep::Entering;
                  ringEnable=true;
                  cout<<"右环2"<<endl;
                }
            }
      }

        // [2] 环岛类型：左入环
        if(ringType == RingType::RingLeft)
        {
          //环岛状态(1)
          if(ringStep == RingStep::Entering)
          {
            if(LsearchBreakLeftUp(track.pointsEdgeLeft,track.edgeleft))
            {
              if(pointBreakLU.y>60)
              {
                int num=abs(pointBreakLU.y-track.edgeright[0].y);
                int stop =track.topline;
                //补线
                vector<Point> r_newPoints = interpolatePoints(track.edgeright[0], pointBreakLU,num);
                track.edgeright.erase(track.edgeright.begin() , track.edgeright.begin() +index);
                track.edgeright.insert(track.edgeright.begin() , r_newPoints.begin(), r_newPoints.end());
                track.edgeleft.erase(track.edgeleft.begin() +index+1, track.edgeleft.end());
                track.edgeright.erase(track.edgeright.begin() +index+1, track.edgeright.end());
                //扫线
                track.tracking(Binaryimg,track.edgeleft[index-1],track.edgeright[index-1],stop);
                //circle(imagePath,track.edgeleft[index-1], 5, Scalar(0,0,255), FILLED);
                //circle(imagePath,track.edgeright[index-1], 5, Scalar(0,0,255), FILLED);
                //cout<<"左:"<<track.edgeleft[index-1]<<","<<"右:"<<track.edgeright[index-1]<<endl;
                //cout<<"1"<<pointBreakLU<<","<<"2"<<track.edgeleft[index];
                circle(imagePath,pointBreakLU, 5, Scalar(0,0,255), FILLED);
              }

              if(!Find)
              {
                if(track.Right_lose_judge[0]==1)
                  Find=true;
              }     
            }
            if(Find)
            {
              if(track.Right_lose_judge[0]==0)
              {
                Find=false;
                cout<<"环中"<<endl;
                ringStep = RingStep::Inside;
              }      
            }
          }
          //环岛状态(2)
          if(ringStep == RingStep::Inside)
          {
            if(LsearchBreakRightDown(track.pointsEdgeRight,track.edgeright))
            {
              circle(imagePath,pointBreakRD, 5, Scalar(0,0,255), FILLED);
              cout<<"退环"<<endl;
              ringStep = RingStep::Exiting;
            }
          }
          //环岛状态(3)
          if(ringStep == RingStep::Exiting)
          {
            if(Straight_Judge(track.edgeright,45,100)<1
              &&track.rightlosenum<35)
            {
              //cout<<"直"<<endl;
              ringStep = RingStep::Finish;
            }
          }
          //环岛状态(4)
          if(ringStep == RingStep::Finish)
          {
            if(LsearchBreakLeftUp(track.pointsEdgeLeft,track.edgeleft))
            {
              if(l_up_row>120)
              {
                cout<<"完环"<<endl;
                ringStep = RingStep::Terminate;
              }
            }
          }
          //环岛状态(5)
          if(ringStep == RingStep::Terminate)
          {
            cout<<"结束"<<endl;
            reset();
          }
        }

        // [3] 环岛类型：右入环
        if(ringType == RingType::RingRight)
        {
          //环岛状态(1)
          if(ringStep == RingStep::Entering)
          {
            if(RsearchBreakRightUp(track.pointsEdgeRight,track.edgeright))
            {
              if(pointBreakRU.y>60)
              {
                int num=abs(pointBreakRU.y-track.edgeleft[0].y);
                int stop =track.topline;

                vector<Point> r_newPoints = interpolatePoints(track.edgeleft[0], pointBreakRU,num);
                track.edgeleft.erase(track.edgeleft.begin() , track.edgeleft.begin() +index);
                track.edgeleft.insert(track.edgeleft.begin() , r_newPoints.begin(), r_newPoints.end());
                track.edgeleft.erase(track.edgeleft.begin() +index+1, track.edgeleft.end());
                track.edgeright.erase(track.edgeright.begin() +index+1, track.edgeright.end());

                track.tracking(Binaryimg,track.edgeleft[index-1],track.edgeright[index-1],stop);
                
                circle(imagePath,pointBreakRU, 5, Scalar(0,0,255), FILLED);
              }
   
              if(!Find)
              {
                if(track.Left_lose_judge[0]==1)
                  Find=true;
              }  
            }
            if(Find)
            {
              if(track.Left_lose_judge[0]==0)
              {
                Find=false;
                cout<<"环中"<<endl;
                ringStep = RingStep::Inside;
              }      
            }
          }
          //环岛状态(2)
          if(ringStep == RingStep::Inside)
          {
            if(RsearchBreakLeftDown(track.pointsEdgeLeft,track.edgeleft))
            {
              circle(imagePath,pointBreakLD, 5, Scalar(0,0,255), FILLED);
              cout<<"退环"<<endl;
              ringStep = RingStep::Exiting;
            }
          }
          //环岛状态(3)
          if(ringStep == RingStep::Exiting)
          {
            if(Straight_Judge(track.edgeleft,45,100)<1
              &&track.leftlosenum<35)
            {
              ringStep = RingStep::Finish;
            }
          }
          //环岛状态(4)
          if(ringStep == RingStep::Finish)
          {
            if(RsearchBreakRightUp(track.pointsEdgeRight,track.edgeright))
            {
              if(r_up_row>120)
              {
                cout<<"完环"<<endl;
                ringStep = RingStep::Terminate;
              }
            }
          }
          //环岛状态(5)
          if(ringStep == RingStep::Terminate)
          {
            cout<<"结束"<<endl;
            reset();
          }
        }

      }
        
  
//private:
/******************************************************左环岛******************************************************/
    /**
     * @brief 搜索圆环赛道突变行（左下）
     * @param pointsEdgeLeft 赛道左边缘点集
     * @param frame 二值化图像
     * @return pointBreakLD 赛道左下拐点
     */
    bool LsearchBreakLeftDown(vector<Point> pointsEdgeLeft,vector<Point> edgeleft)
    {
        for (int i = 5; i < edgeleft.size()-10; i++) 
        {
          if (abs(edgeleft[i + 1].x - edgeleft[i].x) > 10)
          {
              pointBreakLD=edgeleft[i];
              l_down_row=pointBreakLD.y;
              if(LsearchBreakLeftDown1(pointsEdgeLeft))
              {
                return true;
              }
          }
        }

        return false;
    }

    bool LsearchBreakLeftDown1(vector<Point> pointsEdgeLeft)
    {
      for(int i=5;i<pointsEdgeLeft.size()-10;i++)
      {
        if (pointsEdgeLeft[i].y==l_down_row)
        {
          if(pointsEdgeLeft[i].y<pointsEdgeLeft[i-5].y
            &&pointsEdgeLeft[i].y<pointsEdgeLeft[i+5].y
            &&pointsEdgeLeft[i].x>=pointsEdgeLeft[i-5].x
            &&pointsEdgeLeft[i].x>pointsEdgeLeft[i+5].x)
          {
            return true;           
          }
          else
          {
            return false;
          }          
        }
      }  
    }
    /**
     * @brief 搜索圆环赛道突变行（左上）
     * @param pointsEdgeLeft 赛道左边缘点集
     * @param frame 二值化图像
     * @return pointBreakLU 赛道左上拐点
     */
    bool LsearchBreakLeftUp(vector<Point> pointsEdgeLeft,vector<Point> edgeleft)
    {
      for (int i = edgeleft.size()-11; i > 0; i--)
      {
        if (abs(edgeleft[i].x - edgeleft[i-1].x) > 15)
        {
          pointBreakLU=edgeleft[i];
          l_up_row=pointBreakLU.y;
          //v
          if(LsearchBreakLeftUp1(pointsEdgeLeft))
          {
            index=i;
            return true; 
          }
          //直线 
          else
          {
            if(Straight_Judge(edgeleft,i,i+10)<1
              &&loss_judgment(edgeleft,true,i,i+10))
            {
              index=i;
              return true; 
            }
          } 
        }          
      } 
    
      return false;
    }

    bool LsearchBreakLeftUp1(vector<Point> pointsEdgeLeft)
    {
      for(int i=pointsEdgeLeft.size()-5;i>pointsEdgeLeft.size()/2;i--)
      {
        if (pointsEdgeLeft[i].y==l_up_row)
        {
          if(pointsEdgeLeft[i].y>pointsEdgeLeft[i-5].y
            &&pointsEdgeLeft[i].y>pointsEdgeLeft[i+5].y
            &&pointsEdgeLeft[i].x>pointsEdgeLeft[i-5].x
            &&pointsEdgeLeft[i].x<=pointsEdgeLeft[i+5].x)
          {
            return true;           
          }
          else
          {
            return false;          
          }    
        }
      }
    }

    bool LsearchBreakLeftUp2(vector<Point> pointsEdgeLeft)
    {
      for(int i=pointsEdgeLeft.size()-5;i>pointsEdgeLeft.size()/2;i--)
      {
        if (pointsEdgeLeft[i].y==l_up_row)
        {
          if(pointsEdgeLeft[i].y>pointsEdgeLeft[i-5].y
            &&pointsEdgeLeft[i].y>pointsEdgeLeft[i+5].y
            &&pointsEdgeLeft[i].x>pointsEdgeLeft[i-5].x
            &&pointsEdgeLeft[i].x<=pointsEdgeLeft[i+5].x)
          {
            return true;           
          }
          else
          {
            return false;          
          }    
        }
      }
    }

    /**
     * @brief 搜索圆环赛道突变行（右下）
     * @param pointsEdgeRight 赛道右边缘点集
     * @param frame 二值化图像
     * @return pointBreakRD 赛道右下拐点
     */
    bool LsearchBreakRightDown(vector<Point> pointsEdgeRight,vector<Point> edgeright)
    {
      if(edgeright.size() < 5)
      {
          return false;
      }
      for (int i = 5; i < edgeright.size()-5; i++) 
      {
        if(edgeright[i].x<edgeright[i-5].x
          &&edgeright[i].x<edgeright[i+5].x)
        {
          pointBreakRD=edgeright[i];
          index1=i;
          return true;           
        }
      }

      return false;
    }
/******************************************************右环岛******************************************************/
    /**
     * @brief 搜索圆环赛道突变行（右下）
     * @param pointsEdgeRight 赛道右边缘点集
     * @param frame 二值化图像
     * @return pointBreakRD 赛道右下拐点
     */
    bool RsearchBreakRightDown(vector<Point> pointsEdgeRight,vector<Point> edgeright)
    {
      for (int i = 5; i < edgeright.size()-10; i++) 
      {
        if (abs(edgeright[i + 1].x - edgeright[i].x) > 25)
        {
          pointBreakRD=edgeright[i];
          r_down_row=pointBreakRD.y;
          if(RsearchBreakRightDown1(pointsEdgeRight))
          {
            return true;
          }
        }
      }

      return false;
    }
 
    bool RsearchBreakRightDown1(vector<Point> pointsEdgeRight)
    {
      for(int i=5;i<pointsEdgeRight.size()-10;i++)
      {
        if (pointsEdgeRight[i].y==r_down_row)
        {
          if(pointsEdgeRight[i].y<pointsEdgeRight[i-5].y
            &&pointsEdgeRight[i].y<pointsEdgeRight[i+5].y
            &&pointsEdgeRight[i].x<=pointsEdgeRight[i-5].x
            &&pointsEdgeRight[i].x<pointsEdgeRight[i+5].x)
          {
            return true;           
          }
          else
          {
            return false;
          }          
        }
      }  
    }

    /**
     * @brief 搜索十字赛道突变行（右上）
     * @param pointsEdgeRight 赛道右边缘点集
     * @param frame 二值化图像
     * @return pointBreakRU 赛道右上拐点
     */
    bool RsearchBreakRightUp(vector<Point> pointsEdgeRight,vector<Point> edgeright)
    {
      for (int i = edgeright.size()-11; i > 0; i--)
      {
        if (abs(edgeright[i].x - edgeright[i-1].x) > 15)
        {
          pointBreakRU=edgeright[i];
          r_up_row=pointBreakRU.y;
          //v
          if(RsearchBreakRightUp1(pointsEdgeRight))
          {
            index=i;
            return true; 
          }
          //直线 
          else
          {
            if(Straight_Judge(edgeright,i,i+10)<1
              &&loss_judgment(edgeright,false,i,i+10))
            {
              index=i;
              return true; 
            }
          } 
        }          
      } 
    
      return false;
    }

    bool RsearchBreakRightUp1(vector<Point> pointsEdgeRight)
    {
      for(int i=pointsEdgeRight.size()-5;i>pointsEdgeRight.size()/2;i--)
      {
        if (pointsEdgeRight[i].y==r_up_row)
        {
          if(pointsEdgeRight[i].y>pointsEdgeRight[i-5].y
            &&pointsEdgeRight[i].y>pointsEdgeRight[i+5].y
            &&pointsEdgeRight[i].x<pointsEdgeRight[i-5].x
            &&pointsEdgeRight[i].x>=pointsEdgeRight[i+5].x)
          {
            return true;           
          }
          else
          {
            return false;          
          }    
        }
      }
    }

    /**
     * @brief 搜索十字赛道突变行（左下）
     * @param pointsEdgeLeft 赛道左边缘点集
     * @param frame 二值化图像
     * @return pointBreakLD 赛道左下拐点
     */
    bool RsearchBreakLeftDown(vector<Point> pointsEdgeLeft,vector<Point> edgeleft)
    {
      if(edgeleft.size() < 5)
      {
          return false;
      }
      for (int i = 5; i < edgeleft.size()-5; i++) 
      {
        if(edgeleft[i].x>edgeleft[i-5].x
          &&edgeleft[i].x>edgeleft[i+5].x)
        {
          pointBreakLD=edgeleft[i];
          index1=i;
          return true;           
        }
      }

      return false;
    }
/******************************************************属性定义******************************************************/    
  /**
   * @brief 绘制环岛识别图像
   *
   * @param ringImage 需要叠加显示的图像
   */
  void drawImage(Tracking track, Mat &ringImage)
  {
    if(ringEnable)
    {
      putText(ringImage, "[7] RING - ENABLE", Point(COLSIMAGE / 2 - 30, 10),
      cv::FONT_HERSHEY_TRIPLEX, 0.3, cv::Scalar(0, 255, 0), 1, CV_AA);
    }
  }

  bool ringEnable = false;                    // 判环标志
  bool Find = false;
  RingType ringType = RingType::RingNone; // 环岛类型
  RingStep ringStep = RingStep::None;     // 环岛处理阶段

  Point pointBreakLU;     //赛道左上拐点
  Point pointBreakLD;     //赛道左下拐点
  Point pointBreakRU;     //赛道右上拐点
  Point pointBreakRD;     //赛道右下拐点

  int l_down_row;
  int l_up_row;
  int r_down_row;
  int r_up_row;

  int index;
  int index1;
};