/** 
 * @file motion.cpp
 * @brief 运动控制器：PD姿态控制||速度控制
 */

 #include <fstream>
 #include <iostream>
 #include <cmath>
 #include "../include/common.hpp"
 #include "../include/json.hpp"
 
 using namespace std;
 
 class Motion
 {
 private:
     int countShift = 0; // 变速计数器
 
 public:
     /*
      * @brief 初始化：加载配置文件  
      */
     Motion();
 
     /*
      * @brief 控制器核心参数
      */
     struct Params
     {
       float speedLow = 0.8;       // 智能车最低速
       float speedHigh = 0.8;      // 智能车最高速
       float speedBridge = 0.6;    // 坡道速度
       float speedCatering = 0.6;  // 快餐店速度
       float speedLayby = 0.6;     // 临时停车区速度
       float speedBlock= 0.6;
       float speedPeople= 0.6;
       float speedTone= 0.6;
       float speedParking = 0.6;   // 停车场速度
       float speedRing = 0.6;      // 环岛速度
       float speedDown =0.6;       // 倒车速度
       int forword=70;             // 前瞻
       bool bridge = true;         // 坡道区使能
       bool catering = true;       // 快餐店使能
       bool layby = true;          // 临时停车区使能
       bool obstacle = true;       // 障碍区使能
       bool parking = true;        // 停车场使能      
       bool cross = true;          // 十字道路使能
       bool ring = true;           // 环岛使能
       bool charging = true;       // 充电区使能
       float turnP = 3.5;          // 一阶比例系数：转弯控制量
       float turnD = 3.5;          // 一阶微分系数：转弯控制量
       float RingIP = 3.5; 
       float RingID = 3.5; 
       float RingOP = 3.5; 
       float RingOD = 3.5; 
       float ToneP = 3.5; 
       float ToneD = 3.5; 
       float BlockP = 3.5; 
       float BlockD = 3.5;
       float PeopleP = 3.5; 
       float PeopleD = 3.5;
       float LaybyP =2.0;
       float LaybyD = 0.5;
       float score = 0.5;          // AI检测置信度
       bool debug = false;         // 调试模式使能
       bool saveImg = false;       // 存图使能
       bool FPS = false;           // 帧率使能
       bool show = false;           // 
       int Parkingcount = 2;
       int Laybycount = 40;
       int Chargingcount = 40;
       int Cateringcount = 40;
       int Bridgecount = 40;
       int cateringPosion =140;
       int chargingPosion = 65;
       int laybyPosion = 65;
       int LeftPWM = 990;
       int RightPWM = 670;
       string model = "../res/model/yolov3_mobilenet_v1"; // 模型路径
       string video = "../res/samples/demo.mp4";          // 视频路径
       NLOHMANN_DEFINE_TYPE_INTRUSIVE(Params, speedLow, speedHigh, speedBridge,
                                      speedCatering, speedLayby, speedBlock,
                                      speedPeople,speedTone,
                                      speedParking,speedRing, speedDown, forword,                              
                                      bridge, catering, layby, obstacle,
                                      parking, cross, ring,  turnP, turnD, 
                                      RingIP,RingID,RingOP,RingOD,
                                      ToneP,ToneD,BlockP,BlockD,
                                      PeopleP ,PeopleD ,LaybyP ,LaybyD ,
                                      score,debug, saveImg,FPS,show,
                                      Parkingcount, Laybycount,Chargingcount,Cateringcount,Bridgecount,
                                      cateringPosion,chargingPosion,laybyPosion,
                                      model,video); // 添加构造函数
     };
 
     Params params;                   // 读取控制参数
     uint16_t servoPwm = PWMSERVOMID; // 发送给舵机的PWM
     float speed = 20;               // 发送给电机的速度
     float error;
     float turnP = 3.5;          
     float turnD = 3.5;          
     /**
      * @brief 姿态PD控制器
      * @param controlCenter 智能车控制中心
      */
     void poseCtrl(int controlCenter);
 
     /**
      * @brief 变加速控制
      * @param enable 加速使能
      * @param error
      * @param control
      */
     void speedCtrl(bool enable, bool slowDown,float error);
 };
 
 /******************************************************START******************************************************/
 /** 
  * @brief 初始化：加载配置文件  
  */
 Motion::Motion()
 {
     string jsonPath = "../src/config/config.json";
     std::ifstream config_is(jsonPath);
     if (!config_is.good())
     {
         std::cout << "Error: Params file path:[" << jsonPath << "] not find .\n";
         exit(-1);
     }
 
     nlohmann::json js_value;
     config_is >> js_value;
 
     try
     {
         params = js_value.get<Params>();
     }
     catch (const nlohmann::detail::exception &e)
     {
         std::cerr << "Json Params Parse failed :" << e.what() << '\n';
         exit(-1);
     }
 
     speed = params.speedLow;
     cout << "--- speed:" << params.speedLow<< "m/s"<<endl;
 }; 
 
 /**
  * @brief 姿态PD控制器
  * @param controlCenter 智能车控制中心
  */
 void Motion::poseCtrl(int controlCenter)
 {
     float error = controlCenter - COLSIMAGE / 2; // 图像控制中心转换偏差
     static int errorLast = 0;                    // 记录前一次的偏差
     if (abs(error - errorLast) > COLSIMAGE / 10)
     {
         error = error > errorLast ? errorLast + COLSIMAGE / 10
                                   : errorLast - COLSIMAGE / 10;
     }
 
     int pwmDiff = (error * turnP) + (error - errorLast) * turnD;
 
     errorLast = error;
 
     static uint16_t servoPwmLast = 830;
     servoPwm = (uint16_t)(PWMSERVOMID - pwmDiff); // PWM转换
 
     if(servoPwm>1030)
       servoPwm=1030;
     else if(servoPwm<630)
       servoPwm=630;
     //if(abs(servoPwm-servoPwmLast)<20)
     //{
     //  servoPwm=servoPwmLast;
     //}
     //servoPwmLast=servoPwm;
 }
 
 /**
  * @brief 变加速控制
  * @param enable 加速使能
  * @param error
  * @param control
  */
 void Motion::speedCtrl(bool enable, bool slowDown, float error) {
     // 控制率
     uint8_t controlLow = 0;  // 速度控制下限
     uint8_t controlMid = 1;  // 控制率
     uint8_t controlHigh = 2; // 速度控制上限
 
     if (slowDown) // 低速使能
     {
       speed = params.speedLow;
     } else if (enable) // 加速使能
     {
       float speed_k = 1.0f;
       if (abs(error) <= 5) {
         speed_k = 1.0f;
       } else if (abs(error) <= 10 && abs(error) > 5) {
         speed_k = 1.0f;
       } else if (abs(error) <= 15 && abs(error) > 10) {
         speed_k = 1.0f;
       } else if (abs(error) <= 20 && abs(error) > 15) {
         speed_k = 0.9f;
       } else if (abs(error) <= 30 && abs(error) > 20) {
         speed_k = 0.85f;
       } else if (abs(error) <= 40 && abs(error) > 30) {
         speed_k = 0.80f;
       } else if (abs(error) <= 50 && abs(error) > 40) {
         speed_k = 0.8f;
       } else {
         speed_k = 0.8f;
       }
       speed = controlMid * speed_k;
     }
 }
 /*******************************************************END*******************************************************/
 