/** 
 * @file mapping.cpp
 * @brief 图像的透视变换方法（逆/俯视）
 * @note 通过透视变换提取摄像头上帝视角（俯视）
 * @note IPM计算步骤：
 * [1] 设置逆透视图像的掩膜区域（mask）：包括目标变换区域和变换后的成像区域
 * [2] 求解变换矩阵和逆变矩阵
 * [3] 对图像或坐标进行变换
 */

#include "../include/include/src/mapping.hpp"

/******************************************************START******************************************************/
/**
 * @brief 逆透视
 * @param origSize 输入原始图像Img
 * @param dstSize 输出逆透视图像Img_Unpivot
 */
void Mapping::ImgUnpivot(Mat Img,Mat& Img_Unpivot)
{
    // 原始域：分辨率320x240
    // The 4-points at the input image
    m_origPoints.clear();
    m_origPoints.push_back(Point2f(0, 240));    // 左下
    m_origPoints.push_back(Point2f(320, 240));  // 右下
    m_origPoints.push_back(Point2f(200, 25));   // 右上
    m_origPoints.push_back(Point2f(120, 25));   // 左上

    // 矫正域：分辨率320x240
    // The 4-points correspondences in the destination image
    m_dstPoints.clear();
    m_dstPoints.push_back(Point2f(80, 300));   // 左下
    m_dstPoints.push_back(Point2f(240, 300));  // 右下
    m_dstPoints.push_back(Point2f(240, 0));    // 右上
    m_dstPoints.push_back(Point2f(80, 0));     // 左上
    
	Mat UnpivotMat = getPerspectiveTransform(m_origPoints , m_dstPoints);

    warpPerspective(Img , Img_Unpivot , UnpivotMat , Size(320,240) , INTER_LINEAR);
}

void  Mapping::ImagePerspective_Init(Mat& inputImage)
{
    // 确保输入图像与期望的分辨率匹配
    CV_Assert(inputImage.size() == Size(320, 240));

    PER_IMG = inputImage.clone();
    ImageUsed = Mat::zeros(RESULT_ROW, RESULT_COL, PER_IMG.type());

    double change_un_Mat[3][3] = { {0.492560,-0.433276,54.069571},{0.042238,0.090606,15.134632},{0.000136,-0.002658,0.806281} };
 
    for (int i = 0; i < RESULT_COL; i++) 
    {
        for (int j = 0; j < RESULT_ROW; j++) 
        {
            // 计算源图像中的对应点
            double x_src = change_un_Mat[0][0] * i + change_un_Mat[0][1] * j + change_un_Mat[0][2];
            double y_src = change_un_Mat[1][0] * i + change_un_Mat[1][1] * j + change_un_Mat[1][2];
            double w = change_un_Mat[2][0] * i + change_un_Mat[2][1] * j + change_un_Mat[2][2];

            // 转换为整数坐标，并检查边界
            int x_int = static_cast<int>(x_src / w);
            int y_int = static_cast<int>(y_src / w);
            if (x_int >= 0 && y_int >= 0 && x_int < USED_COL && y_int < USED_ROW)
            {
                ImageUsed.at<uchar>(j, i) = PER_IMG.at<uchar>(y_int, x_int);
            }
            else 
            {
                ImageUsed.at<uchar>(j, i) = 0; 
            }
        }
    }
}
/*******************************************************END*******************************************************/