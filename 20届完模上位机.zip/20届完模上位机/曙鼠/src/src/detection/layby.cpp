#pragma once

 #include <fstream>
 #include <iostream>
 #include <cmath>
 #include <opencv2/highgui.hpp>
 #include <opencv2/opencv.hpp>
 #include "../../include/common.hpp"
 #include "../../include/detection.hpp"
 #include "../recognition/tracking.cpp"

using namespace cv;
using namespace std;

class Layby
{
public:
    /**
     * @brief 场景状态
     */
    enum Step
    {
        none = 0,
        init, // 识别到标识
        first,      // 只找下点
        second,   // 上下点同时找
        stop,      // 只找上点并且准备停车
        finish
    };

    Step step=Step::none;
    bool laybyEnable = false;       
    bool leftEnable = true; 
    bool stopEnable = false;        // 停车使能标志
    bool noRing = false;            // 用来区分环岛路段

    bool process(Tracking &track, Mat &image, vector<PredictResult> predict,int Laybycount,int laybyPosion)
    {
        if (laybyEnable) // 进入临时停车状态
        {   
            Clear_Layby();
            
            switch (step)
            {
                case Step::init:
                    if(seekdownpoint(track.edgeleft,track.edgeright,image,leftEnable))
                    {
                        step=Step::first;
                    }
                    break;

                case Step::first:
                    if(seekdownpoint(track.edgeleft,track.edgeright,image,leftEnable)&&seekuppoint(track.edgeleft,track.edgeright,image,leftEnable))
                    {
                        if(abs(Layby_line_up[0].y-Layby_line_down[0].y)>20&&Layby_line_down[0].y>180)
                        {
                            step=Step::second;
                        }                 
                    }
                    break;

                case Step::second:
                    if(seekuppoint(track.edgeleft,track.edgeright,image,leftEnable))
                    {
                        if(Layby_line_up[0].y>laybyPosion)
                            step=Step::stop;
                    }
                    break;

                case Step::stop:
                    cout << "开始临时停车" << std::endl;
                    step=Step::finish;
                    stopEnable = true;    // 停车使能
                    break;

                case Step::finish:   
                    if(stopEnable)
                    {
                        exit++;
                        if(exit>Laybycount)
                        {
                            exit=0;
                            laybyEnable = false;       
                            leftEnable = false;                        
                            noRing = false; 
                            step=Step::none;
                            stopEnable = false;    // 停车使能
                            return false;
                        }
                    }
                    break;
            }

            return true;
        }
        else
        {
            for (size_t i = 0; i < predict.size(); i++)
            {
                if (((predict[i].type == LABEL_SCHOOL || predict[i].type == LABEL_COMPANY)  && predict[i].score > 0.4)  && (predict[i].y + predict[i].height) > ROWSIMAGE * 0.3)
                {
                    counterRec++;
                    if (predict[i].x < COLSIMAGE / 2)   // 标识牌在左侧
                        leftEnable = true;                     
                    else           
                        leftEnable = false;          
                 
                    noRing = true;
                    break;
                }
            }

            if (counterRec)
            {
                counterSession++;
                if (counterRec >= 1)// && counterSession < 8)
                {
                    counterRec = 0;
                    counterSession = 0;
                    step=Step::init;
                    laybyEnable = true; // 检测到标识牌子
                    return true;
                }
                else if (counterSession >= 8)
                {
                    counterRec = 0;
                    counterSession = 0;
                }
            }

            return false;
        }    
    }

    // [1]下点
    bool seekdownpoint(vector<Point> pointsEdgeLeft,vector<Point> pointsEdgeRight,Mat &image,bool left)
    {
        if(left)
        {
            if (pointsEdgeLeft.size() < 3) {
                return false; // 或处理错误
            }
            for (int i = 0; i < pointsEdgeLeft.size()/2; i++)
            {
              if (abs(pointsEdgeLeft[i].x - pointsEdgeLeft[i+2].x) >3)
              { 
                    cout <<pointsEdgeLeft[i+2].y << std::endl;
                  Layby_line_down.push_back(pointsEdgeLeft[i+2]);
                  line(image,Point(0,Layby_line_down[0].y),Point(319,Layby_line_down[0].y),Scalar(0,0,255),1);
                  return true;                  
              }
            }
        }
        else
        {
            if (pointsEdgeRight.size() < 3) {
                return false; // 或处理错误
            }
            for (int i = 0; i < pointsEdgeRight.size()/2; i++)
            {
              if (abs(pointsEdgeRight[i].x - pointsEdgeRight[i+2].x) >3)
              { 
                cout <<"右下："<<i<<"."<<pointsEdgeRight[i+2].y << std::endl;
                  Layby_line_down.push_back(pointsEdgeRight[i+2]);
                  line(image,Point(0,Layby_line_down[0].y),Point(319,Layby_line_down[0].y),Scalar(0,0,255),1);
                  return true;                  
              }
            }
        }

      return false;
    }

    // [2]上点
    bool seekuppoint(vector<Point> pointsEdgeLeft,vector<Point> pointsEdgeRight,Mat &image,bool left)
    {
        if(left)
        {
            if(pointsEdgeLeft.size()>10)
            {
            for (int i = pointsEdgeLeft.size() -10; i > 30; i--)
            {
              if (abs(pointsEdgeLeft[i - 2].x - pointsEdgeLeft[i].x) >3)
              { 
                Layby_line_up.push_back(pointsEdgeLeft[i-2]);
                line(image,Point(0,Layby_line_up[0].y),Point(319,Layby_line_up[0].y),Scalar(0,0,255),2);
                return true;                  
              }
            }
            }
        }
        else
        {
            if(pointsEdgeRight.size()>10)
            {
            for (int i = pointsEdgeRight.size() -1; i > 30; i--)
            {
              if (abs(pointsEdgeRight[i - 2].x - pointsEdgeRight[i].x) >3)
              { 
                Layby_line_up.push_back(pointsEdgeRight[i-2]);
                line(image,Point(0,Layby_line_up[0].y),Point(319,Layby_line_up[0].y),Scalar(0,0,255),1);
                return true;                  
              }
            }
            }
        }

      return false;
    }
 
    void Clear_Layby()
    {
        Layby_line_up.clear();
        Layby_line_down.clear();
    }

    /**
     * @brief 识别结果图像绘制
     *
     */
    void drawImage(Tracking track, Mat &image)
    {   
        if (laybyEnable)
            putText(image, "[1] Layby - ENABLE", Point(COLSIMAGE / 2 - 30, 10), cv::FONT_HERSHEY_TRIPLEX, 0.3, cv::Scalar(0, 255, 0), 1, CV_AA);
    }

private:
    uint16_t counterSession = 0;    
    uint16_t counterRec = 0;  
    uint16_t exit = 0;                         
    vector<Point> Layby_line_up;
    vector<Point> Layby_line_down;
};