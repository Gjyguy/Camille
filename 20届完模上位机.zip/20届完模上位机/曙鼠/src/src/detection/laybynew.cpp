#pragma once

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../../include/common.hpp"
#include "../../include/detection.hpp"
#include "../recognition/tracking.cpp"

using namespace cv;
using namespace std;

class Layby
{
public:
    /**
     * @brief 场景状态
     */
    enum Step
    {
        none = 0,
        lower,    // 只找下点
        middle,   // 找上下点对比
        upper,    // 只找上点
        stop,      // 只找上点并且准备停车
        finish
    };

    /**
     * @brief 汉堡复位
     */
    void reset(void) 
    {
        step=Step::none;
        laybyEnable = false;       
        leftEnable = false; 
        stopEnable = false;        // 停车使能标志
        noRing = false;            // 用来区分环岛路段
    
        lowerPoint = 0;       // 下点所在行数
        lowerBefore = 0;      // 前一个下点所在行数
    
        upperPoint = 0;       // 上点所在行数
        upperBefore = 0;      // 前一个上点点所在行数
    
        lowerPosY = 0;        // 下点所在 Y轴 坐标
        upperPosY = 0;        // 上点所在 Y轴 坐标

        stopTime = 0;
    }

    Step step=Step::none;
    bool laybyEnable = false;       
    bool leftEnable = false; 
    bool stopEnable = false;        // 停车使能标志
    bool noRing = false;            // 用来区分环岛路段

    int lowerPoint = 0;       // 下点所在行数
    int lowerBefore = 0;      // 前一个下点所在行数

    int upperPoint = 0;       // 上点所在行数
    int upperBefore = 0;      // 前一个上点点所在行数

    int lowerPosY = 0;        // 下点所在 Y轴 坐标
    int upperPosY = 0;        // 上点所在 Y轴 坐标

    bool process(Tracking &track, Mat &image, vector<PredictResult> predict,int &Laybycount,int &laybyPosion)
    {
        if (laybyEnable) // 进入临时停车状态
        {
            if(step==Step::lower||step == Step::middle)
                lowerPoint = seeklower(track.edgeleft, track.edgeright, image, leftEnable); // 找下点
            else
                lowerPoint = 10;

            if(step!=Step::lower)
            {
                upperPoint = seekupper(track.edgeleft, track.edgeright, image, leftEnable,lowerPoint+10); // 找上点
                if (!upperPoint )
                    upperPoint = 79;
            }

            if (leftEnable)
            {
                lowerPosY = track.edgeleft[lowerPoint].y;
                upperPosY = track.edgeleft[upperPoint].y;
            }
            else
            {
                lowerPosY = track.edgeright[lowerPoint].y;
                upperPosY = track.edgeright[upperPoint].y;
            }

            switch (step) // 临时停车状态判断
            {
                case Step::lower:
                {
                    cout << "--------------------> statue 1" << endl;
            

                    if (lowerPoint)
                    {
                        circle(image,track.edgeleft[lowerPoint], 5, Scalar(0,255,0), FILLED);
                        step = Step::middle;
                    }
                        
                    break;
                }
    
                case Step::middle:
                {
                    cout << "--------------------> statue 2" << endl;

                    if (lowerPoint && upperPoint && lowerPosY > 180&&(lowerPosY-upperPosY)>20)
                    {

                        step = Step::upper;
                    }
                      
                    break;
                }
    
                case Step::upper:
                {
                    cout << "--------------------> statue 3" << endl;
                    if (upperPosY > laybyPosion)
                        step = Step::stop;    
                    break;
                }
    
                case Step::stop:
                {
                    cout << "--------------------> statue 4" << endl;
                    stopTime++;
                    stopEnable = true;    // 停车使能
                    if (stopTime >= Laybycount)
                    {
                        stopTime = 0;
                        step = Step::finish;
                    }
                    break;
                }

                case Step::finish:
                {
                    cout << "--------------------> statue 5" << endl;
                    reset();
                    break;
                }
            }

            //line(image,Point(0,lowerPosY),Point(319,lowerPosY),Scalar(0,0,255),1);
            //line(image,Point(0,upperPosY),Point(319,upperPosY),Scalar(0,0,255),1);
            cout << lowerPosY << " " << upperPosY << endl;
           
            return true;
        }

        else // 检测标志
        {
            for (size_t i = 0; i < predict.size(); i++)
            {
                if (((predict[i].type == LABEL_SCHOOL || predict[i].type == LABEL_COMPANY)  && predict[i].score > 0.8)  && (predict[i].y + predict[i].height) > ROWSIMAGE * 0.3)
                {
                    counterRec++;
                    if (predict[i].x < COLSIMAGE / 2)   // 标识牌在左侧
                        leftEnable = true;                     
                    else           
                        leftEnable = false;          
                 
                    noRing = true;
                    break;
                }
            }

            if (counterRec)
            {
                counterSession++;
                if (counterRec >= 1)// && counterSession < 8)
                {
                    counterRec = 0;
                    counterSession = 0;
                    step=Step::lower;
                    laybyEnable = true; // 检测到标识牌子
                    return true;
                }
                else if (counterSession >= 8)
                {
                    counterRec = 0;
                    counterSession = 0;
                }
            }

            return false;
        } 
    }

    // 找下点
    int seeklower(const vector<Point> &edgeleft, const vector<Point> &edgeRight, Mat &image, bool left)
    {
        if (left)
        {
            if (edgeleft.size() < 10) 
                return 0;  // 点太少无法检测
            
            for (int i = 0; i < edgeleft.size()/2; i++) 
            {
                if (abs(edgeleft[i].x - edgeleft[i+2].x) >3)
                {
                    return i + 2;
                }      
            }
        }
        else
        {
            if (edgeRight.size() < 10) 
                return 0;  // 点太少无法检测
            
            for (int i = 0; i < edgeRight.size()/2; i++) 
            {

                if (abs(edgeRight[i].x - edgeRight[i+2].x) >3)
                { 
                    return i + 2;
                }
            }
        }

        return 0;
    }

    // 找上点
    int seekupper(const vector<Point> &edgeleft, const vector<Point> &edgeRight, Mat &image, bool left,int start)
    {
        if (left)//左
        {
            if (edgeleft.size() < 10) 
                return 0;  // 点太少无法检测

            for (int i = start; i < edgeleft.size()-20; i++) 
            {
                if (abs(edgeleft[i].x - edgeleft[i+2].x) >3) 
                { 
                    return i + 2;
                }
            }
        }
        else//右
        {
            if (edgeRight.size() < 10) 
                return 0;  // 点太少无法检测
    
            for (int i = start; i < edgeRight.size()-20; i++) 
            {
                if (abs(edgeRight[i].x - edgeRight[i+2].x) >3) 
                { 
                    return i + 2;
                }
            }
        }

        return 0;
    }

private:
    uint16_t counterSession = 0;    
    uint16_t counterRec = 0;  
    int stopTime = 0;         // 停车耗时
};

