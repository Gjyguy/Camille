   #pragma once
/**
 * @file parking.cpp
 * @brief 停车区AI识别与路径规划
 */

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../../include/common.hpp"
#include "../../include/detection.hpp" // Ai模型预测

using namespace std;
using namespace cv;

/**
 * @brief 停车区AI识别与路径规划类
 *
 */
class Parking
{
    public:
    /**
     * @brief 场景状态
     */
    enum Step
    {
        init = 0, // 初始化屏蔽
        det,      // AI标识检测
        enable,   // 场景使能
        stop      // 准备停车
    };

    Step step = Step::init; // 场景状态
    uint16_t countRec = 0;  // AI场景识别计数器
    uint16_t countSes = 0;  // 场次计数器

    uint16_t countExit = 0; // 程序退出计数器
    bool park = false;      // 斑马线标志

    /**
     * @brief 停车区AI识别与路径规划处理
     * @param predict AI检测结果
     * @return true
     * @return false
     */
    bool process(vector<PredictResult> predict,int Parkingcount);

    /**
     * @brief 图像绘制禁行区识别结果
     * @param img 需要叠加显示的图像
     */
    void drawImage(Mat &img);    
};

/******************************************************START******************************************************/
/**
 * @brief 停车区AI识别与路径规划处理
 * @param predict AI检测结果
 * @return true
 * @return false
 */
bool Parking::process(vector<PredictResult> predict,int Parkingcount)
{
    switch (step)
    {
    //[1]初始化：起点斑马线屏蔽
    case Step::init:
        countSes++;
        for (int i = 0; i < predict.size(); i++)
        {
            if (predict[i].type == LABEL_CROSSWALK) // AI识别标志
            {
                
                if ((predict[i].y + predict[i].height) > ROWSIMAGE * 0.2) // 标志距离计算
                {
                    countSes = 0;
                    break;
                }
            }
        }
        if (countSes > 50)
        {
            countSes = 0;
            step = Step::det;
        }
        break;

    //[2]AI识别斑马线
    case Step::det:
        for (int i = 0; i < predict.size(); i++)
        {
            if (predict[i].type == LABEL_CROSSWALK) // AI识别标志
            {
                if ((predict[i].y + predict[i].height) > ROWSIMAGE * 0.4) // 标志距离计算
                {
                    countRec++;
                    break;
                }
            }
        }
        if (countRec) // 识别AI标志后开始场次计数
            countSes++;

        if (countSes >= 8)
        {
            if (countRec >= 1)
            {
                step = Step::enable;
            }
            else
            {
                countRec = 0;
                countSes = 0;
            }
        }
        break;
        
    //[3]场景使能: 检测斑马线标识丢失
    case Step::enable:
        countSes++;
        for (int i = 0; i < predict.size(); i++)
        {
            if (predict[i].type == LABEL_CROSSWALK) // AI识别标志
            {
                if (predict[i].y > ROWSIMAGE * 0.3) // 标志距离计算
                {
                    countSes = 0;
                    break;
                }
            }
        }
        
        if (countSes > Parkingcount)
        {
            countExit = 0;
            step = Step::stop;
        }
        break;

    //[4]准备停车
    case Step::stop: // 准备停车
        countExit++; // 停车倒计时
        break;
    }

    // 输出场景状态结果
    if (step == Step::init || step == Step::det)
        return false;
    else
        return true;
}

/**
 * @brief 图像绘制禁行区识别结果
 * @param img 需要叠加显示的图像
 */
void Parking::drawImage(Mat &img)
{
    if (step == Step::enable)
        putText(img, "[5] PARK - ENABLE", Point(COLSIMAGE / 2 - 30, 10), cv::FONT_HERSHEY_TRIPLEX, 0.3, cv::Scalar(0, 255, 0), 1, CV_AA);       
} 
/*******************************************************END*******************************************************/