/**
 * @file obstacle.cpp
 * @brief 障碍区AI识别与路径规划
 */
#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../../include/common.hpp"
#include "../../include/detection.hpp" // Ai模型预测

using namespace std;
using namespace cv;

/**
 * @brief 危险区AI识别与路径规划类
 *
 */


class Obstacle
{
public:
    PredictResult ResultObs; // 避障目标锥桶
    PredictResult resultObs; // 最终避障对象
    bool enable = false;     // 场景检测使能标志
    bool coneleft = false;
    bool coneright = false;
    bool peopleleft = false;
    bool peopleright = false;
    bool blockleft = false;
    bool blockright = false;

    void reset()
    {
        enable = false;     // 场景检测使能标志
        coneleft = false;
        coneright = false;
        peopleleft = false;
        peopleright = false;
        blockleft = false;
        blockright = false;
    }
    /**
     * @brief 危险区AI识别与路径规划处理
     * @param track 赛道识别结果
     * @param predict AI检测结果
     * @return true
     * @return false
     */
    bool process(Tracking &track, vector<PredictResult> predict,Mat &img)
    {
        reset();

        if (track.edgeleft.size() < ROWSIMAGE / 6 || track.edgeright.size() < ROWSIMAGE / 6)//40
            return enable;

        vector<PredictResult> resultsObs; // 锥桶AI检测数据

        for (size_t i = 0; i < predict.size(); i++)
        {
            if (( predict[i].type == LABEL_BLOCK || predict[i].type == LABEL_PEDESTRIAN) && (predict[i].y + predict[i].height) < 200) // AI标志距离计算
                resultsObs.push_back(predict[i]);
        }

        if(searchCones(track,img))
            resultsObs.push_back(ResultObs);
            
        if (resultsObs.size() <= 0)
            return enable;
         
        // 选取距离最近的锥桶
        int index = 0;   // 目标序号
        int y_near = 0;
        for (size_t i = 0; i < resultsObs.size(); i++)
        {     
            if (resultsObs[i].y > y_near)
            {
                index = i;
                y_near = resultsObs[i].y;
            }
        }

        resultObs = resultsObs[index];
        enable = true; // 场景检测使能标志

        switch (resultObs.type)
        {
            case LABEL_CONE:
                cout<<"锥桶"<<endl;
                break;

            case LABEL_PEDESTRIAN:
                people_deal(track,resultObs,img);
                cout<<"行人"<<endl;
                break;

            case LABEL_BLOCK:
                block_deal(track,resultObs,img);
                cout<<"黑块"<<endl;
                break;
        }           
        return enable;
    }           

private:
    bool searchCones(Tracking &track,Mat &img) 
    {
        Rect Cone;
        bool enable=false;

        //锥桶检测
        Mat hsv;
        cvtColor(img, hsv, COLOR_BGR2HSV);
        // 定义黄色的HSV范围
        Scalar lowerYellow(15, 100, 60);
        Scalar upperYellow(35, 255, 255);
        
        Mat Mask;
        inRange(hsv, lowerYellow, upperYellow, Mask);

        vector<vector<Point>> contours;
        findContours(Mask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
                    
        int y_Near = 0; // 行坐标
        if (!contours.empty())
        {
            // 选取距离最近的锥桶   
            int a =0;
            int y_Near = 0; // 行坐标
            for (const auto& contour : contours)
            {
                Rect Tempcone = boundingRect(contour);
                if(Tempcone.y>ROWSIMAGE/3&& Tempcone.y+Tempcone.height < ROWSIMAGE- 20&& Tempcone.y > y_Near)
                {
          
                    int row = track.edgeleft.size() - (Tempcone.y - track.rowCutUp);
                    if (row<0||Tempcone.width*Tempcone.height<250) // 太远不管
                    {
                        continue;
                    }
                    int center = Tempcone.x + Tempcone.width / 2;
                    int disLeft = center - track.edgeleft[row].x;  //障碍右侧到左边线的水平距离
                    int disRight = track.edgeright[row].x - center;  //右边线到障碍左侧的水平距离
                    y_Near = Tempcone.y;
                    a++;
                    //cout<<"面积:"<<Tempcone.width*Tempcone.height<<endl;
                    //cout<<"左距离"<<disLeft<<"."<<"右距离"<<disRight<<endl;
                    
                    if(disLeft>=0 && disRight>=0)
                    {
                       enable = true;
                       Cone = Tempcone;
                       y_Near = Tempcone.y; 
                       if (disLeft <= disRight) //[1] 障碍物在赛道内， 且靠左
                       {
                            coneleft = true;
                            coneright =false;
                       }
                       else if (disLeft > disRight) //[2] 障碍物在赛道内，且靠右
                       {
                            coneleft = false;
                            coneright = true;
                       }
                       line(img,Point(center,0),Point(center,239),Scalar(0,0,255),2);
                       line(img,Point(0,track.edgeleft[row].y),Point(319,track.edgeleft[row].y),Scalar(255,0,0),2);
                    }
                }
                
            }
            //cout<<"锥桶数量:"<<a<<endl;
        }


        if(enable)
        {
            ResultObs.type = LABEL_CONE;
            ResultObs.x = Cone.x;
            ResultObs.y = Cone.y;
            ResultObs.height = Cone.height;
            ResultObs.width = Cone.width;     
        }

        if(enable)
        {
            Rect rect(ResultObs.x, ResultObs.y, ResultObs.width, ResultObs.height);
            rectangle(img, rect, cv::Scalar(0, 0, 255), 1);
        } 
        return enable;
    }

    void block_deal(Tracking &track,PredictResult &resultObs,Mat &img)
    {
        if(resultObs.y>ROWSIMAGE/4)//60
        {
            int row = track.edgeleft.size() - (resultObs.y - track.rowCutUp);
            int center = resultObs.x + resultObs.width / 2;
            int disLeft = center - track.edgeleft[row].x;  //障碍右侧到左边线的水平距离
            int disRight = track.edgeright[row].x - center;  //右边线到障碍左侧的水平距离

            line(img,Point(center,0),Point(center,239),Scalar(0,0,255),2);
            line(img,Point(0,track.edgeleft[row].y),Point(319,track.edgeleft[row].y),Scalar(255,0,0),2);

            if(disLeft>=0 && disRight>=0&&resultObs.x>track.edgeleft[row].x&&resultObs.x<track.edgeright[row].x)
            {

                if (disLeft <= disRight) //[1] 障碍物在赛道内， 且靠左
                {
                    blockleft = true;
                    blockright =false;
                }
                else if (disLeft > disRight) //[2] 障碍物在赛道内，且靠右
                {
                    blockleft = false;
                    blockright = true;
                }
            }
        }
    }

    void people_deal(Tracking &track,PredictResult &resultObs,Mat &img)
    {
        if(resultObs.y>ROWSIMAGE/4)//60
        {
            int row = track.edgeleft.size() - (resultObs.y - track.rowCutUp);
            int center = resultObs.x + resultObs.width / 2;
            int disLeft = center - track.edgeleft[row].x;  //障碍右侧到左边线的水平距离
            int disRight = track.edgeright[row].x - center;  //右边线到障碍左侧的水平距离

            line(img,Point(center,0),Point(center,239),Scalar(0,0,255),2);
            line(img,Point(0,track.edgeleft[row].y),Point(319,track.edgeleft[row].y),Scalar(255,0,0),2);
            
            if(disLeft>=0 && disRight>=0&&resultObs.x>track.edgeleft[row].x&&resultObs.x<track.edgeright[row].x)
            {

                if (disLeft <= disRight) //[1] 障碍物在赛道内， 且靠左
                {
                    peopleleft = true;
                    peopleright =false;
                }
                else if (disLeft > disRight) //[2] 障碍物在赛道内，且靠右
                {
                    peopleleft = false;
                    peopleright = true;
                }
            }
        }
    }
};
