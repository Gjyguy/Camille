#pragma once

/**
 * @file catering.cpp
 * @brief 餐饮区
 */

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../../include/common.hpp"
#include "../../include/detection.hpp"
#include "../recognition/tracking.cpp"

using namespace cv;
using namespace std;

class Catering
{
public:
    bool noRing = false;            // 用来区分环岛路段

    /**
     * @brief 场景状态
     */
    enum Step
    {
        none = 0,
        turn,
        stop,      // 只找上点并且准备停车
        finish,
        exiting
    };

    /**
     * @brief 汉堡复位
     */
    void reset(void) 
    {
        counterRec = 0;
        counterSession = 0;
        cateringEnable = false;
        stopenable=false;
        noRing = false;      // 区分环岛   
        step=Step::none;
    }

    Step step=Step::none;
    bool stopenable=false;

    bool process(Tracking &track, Mat &image, vector<PredictResult> predict,int Cateringcount,int cateringPosion)
    {
        if (cateringEnable) 
        { 
            //左汉堡
            if(burgerLeft)
            {
                switch (step)
                {
                    case Step::turn:
                        if(!stopenable)
                        {
                            if(Straight_Judge(track.edgeright,0,130)<1)
                                stopenable=true;
                        }
    
                        if(stopenable)
                        {
                            //寻找上角点(判断停车)     
                            if(LeftsearchBreak(track.edgeleft))
                            {
                                circle(image,LeftpointBreak, 5, Scalar(0,0,255), FILLED);
                                if(LeftpointBreak.y>cateringPosion)
                                    step=Step::stop;
                            }
                        }
                        break;
    
                    case Step::stop:
                        counterSession++;
                        if(counterSession>Cateringcount)
                        {
                            counterSession=0;
                            step=Step::finish;
                        }
                        break;
    
                    case Step::finish:
                        if(Straight_Judge(track.edgeright,50,100)>1)
                        {
                            step=Step::exiting;
                        }
                        break;

                    case Step::exiting:
                        if((Straight_Judge(track.edgeleft,5,110)<1&&track.leftlosenum<10)
                        ||(Straight_Judge(track.edgeright,5,110)<1&&track.rightlosenum<10))
                        {
                            reset();
                        }
                    break;
                }
            }
            //右汉堡
            else
            {
                switch (step)
                {
                    case Step::turn:
                        if(!stopenable)
                        {
                            if(Straight_Judge(track.edgeleft,0,130)<1)
                                stopenable=true;
                        }
    
                        if(stopenable)
                        {
                            //寻找上角点(判断停车)     
                            if(RightsearchBreak(track.edgeright))
                            {
                                circle(image,RightpointBreak, 5, Scalar(0,0,255), FILLED);
                                cout<<RightpointBreak.y<<endl;
                                if(RightpointBreak.y>cateringPosion)
                                    step=Step::stop;
                            }
                        }
                        break;
    
                    case Step::stop:
                        counterSession++;
                        if(counterSession>Cateringcount)
                        {
                            counterSession=0;
                            step=Step::finish;
                        }
                        break;
    
                    case Step::finish:
                        if(Straight_Judge(track.edgeleft,50,100)>1)
                        {
                            step=Step::exiting;
                        }
                        break;

                    case Step::exiting:
                        if((Straight_Judge(track.edgeleft,5,110)<1&&track.leftlosenum<10)
                        ||(Straight_Judge(track.edgeright,5,110)<1&&track.rightlosenum<10))
                        {
                            reset();
                        }
                    break;
                }
            }   
            return true;  
        }
        else // 检测汉堡标志
        {
            for (size_t i = 0; i < predict.size(); i++)
            {
                if (predict[i].type == LABEL_BURGER && predict[i].score > 0.8 && (predict[i].y + predict[i].height) > ROWSIMAGE * 0.3)
                {
                    counterRec++;
                    noRing = true;
                    if (predict[i].x < COLSIMAGE / 2)   // 汉堡在左侧
                        burgerLeft = true;
                    else
                        burgerLeft = false;
                    break;
                }
            }

            if (counterRec)
            {
                counterSession++;
                if (counterRec >= 1 && counterSession < 8)
                {
                    counterRec = 0;
                    counterSession = 0;
                    step=Step::turn;
                    cateringEnable = true; // 检测到汉堡标志
                    return true;
                }
                else if (counterSession >= 8)
                {
                    counterRec = 0;
                    counterSession = 0;
                }
            }

            return false;
        }
    }
  
    /**
     * @brief 搜索汉堡突变行（左下）
     * @param edgeleft 赛道左边缘点集
     * @return LeftpointBreak 赛道左下拐点
     */
    bool LeftsearchBreak(vector<Point> &edgeleft)
    {
        if (edgeleft.size() < 10) 
            return 0;  // 点太少无法检测

        for (int i = edgeleft.size()/2; i< edgeleft.size()-5; i++) 
        {
            if(abs(edgeleft[i+1].x-edgeleft[i].x)>15&&edgeleft[i+1].x<edgeleft[i].x)
            {
                LeftpointBreak=edgeleft[i];
                return true;           
            }
        }

      return false;
    }    

    /**
     * @brief 搜索汉堡突变行（右下）
     * @param edgeright 赛道右边缘点集
     * @return RightpointBreak 赛道右下拐点
     */
    bool RightsearchBreak(vector<Point> &edgeright)
    {
        if (edgeright.size() < 10) 
            return false;  // 点太少无法检测

        for (int i = edgeright.size()/2; i < edgeright.size()-5; i++) 
        {
            if(abs(edgeright[i+1].x-edgeright[i].x)>15&&edgeright[i].x<edgeright[i+1].x)
            {
                RightpointBreak=edgeright[i];
                return true;           
            }
        }

        return false;
    }

    /**
     * @brief 识别结果图像绘制
     *
     */
    void drawImage(Tracking track, Mat &image)
    {  
        if (cateringEnable)
            putText(image, "[1] Burger - ENABLE", Point(COLSIMAGE / 2 - 30, 10), cv::FONT_HERSHEY_TRIPLEX, 0.3, cv::Scalar(0, 255, 0), 1, CV_AA);    
    }

//private:
    uint16_t counterSession = 0;    // 图像场次计数器
    uint16_t counterRec = 0;        // 汉堡标志检测计数器
    bool cateringEnable = false;    // 岔路区域使能标志
    bool burgerLeft = true;         // 汉堡在左侧
    Point LeftpointBreak;
    Point RightpointBreak;
};