#pragma once

/**
 * @file bridge.cpp
 * @brief 坡道（桥）路径处理
 */

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../../include/common.hpp"
#include "../../include/detection.hpp"
#include "../recognition/tracking.cpp"

using namespace cv;
using namespace std;

class Bridge
{
public:
    /**
     * @brief 坡道区AI识别与路径规划处理
     * @param predict AI检测结果
     * @return true
     * @return false
     */
    bool process(Tracking &track, vector<PredictResult> predict,int Bridgecount);
 
    /**
     * @brief 识别结果图像绘制
     *
     */
    void drawImage(Mat &image);

//private:
    uint16_t counterSession = 0; // 图像场次计数器
    uint16_t counterRec = 0;     // 坡道标志检测计数器
    bool bridgeEnable = false;   // 桥区域使能标志
};

/******************************************************START******************************************************/
bool Bridge::process(Tracking &track, vector<PredictResult> predict,int Bridgecount)
{
    if (bridgeEnable) // 进入坡道
    {
        counterSession++;
        cout<<"桥"<<counterSession<<endl;
        if (counterSession >Bridgecount) // 上桥40场图像后失效
        {
            counterRec = 0;
            counterSession = 0;
            bridgeEnable = false;
        }

        return true;
    }
    else // 检测坡道
    {
        for (size_t i = 0; i < predict.size(); i++)
        {
            if (predict[i].type == LABEL_BRIDGE && predict[i].score > 0.6 && (predict[i].y + predict[i].height) > ROWSIMAGE * 0.3)
            {
                counterRec++;
                break;
            }
        }

        if (counterRec)
        {
            counterSession++;
            if (counterRec >= 2 && counterSession < 8)
            {
                counterRec = 0;
                counterSession = 0;
                bridgeEnable = true; // 检测到桥标志
                return true;
            }
            else if (counterSession >= 8)
            {
                counterRec = 0;
                counterSession = 0;
            }
        }

        return false;
    }
}

/**
 * @brief 识别结果图像绘制
 *
 */
void Bridge::drawImage(Mat &image)
{
    if (bridgeEnable)
        putText(image, "[1] BRIDGE - ENABLE", Point(COLSIMAGE / 2 - 30, 10), cv::FONT_HERSHEY_TRIPLEX, 0.3, cv::Scalar(0, 255, 0), 1, CV_AA);       
}
/*******************************************************END*******************************************************/