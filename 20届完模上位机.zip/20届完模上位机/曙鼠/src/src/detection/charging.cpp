#pragma once

/**
 * @file Charging.cpp
 * @brief 充电停车场
 */

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../../include/common.hpp"
#include "../../include/detection.hpp"
#include "../recognition/tracking.cpp"

using namespace cv;
using namespace std;

/**
 * @file Charging.cpp
 * @brief 充电区路径处理
 */

class Charging
{
    public:
    /**
     * @brief 停车步骤
     *
     */
    enum Step
    {
        none = 0, // 未知状态
        enable,   // 停车场使能
        turning,  // 入库转向
        stop,     // 停车
        trackout,  // 出库
        exiting
    };

        /**
     * @brief 汉堡复位
     */
    void reset(void) 
    {
        counterRec = 0;
        counterSession = 0;
        ChargingEnable = false;
        step=Step::none;
        noRing = false; 
    }

    Step step = Step::none; // 停车步骤
    bool noRing = false;            // 用来区分环岛路段
    bool process(Tracking &track, Mat &image, vector<PredictResult> predict,int Chargingcount,int chargingPosion)
    {
        if(ChargingEnable)
        {
            if(ChargingLeft)
            {
                switch (step)
                {
                    case Step::enable: // 停车场使能
                    {
                        if(track.edgeleft.size()>30)
                        {
                            for(int i=track.edgeleft.size()-5;i>30;i--)
                            {
                                if((track.edgeleft[i-1].x-track.edgeleft[i].x)>10&&track.Left_lose_judge[i-1])
                                {
                                    ptA=track.edgeleft[i];
        
                                    circle(image,ptA, 5, Scalar(0,0,255), FILLED);
                                    line(image,Point(0,ptA.y),Point(319,ptA.y),Scalar(0,0,255),1);
                                    cout<<ptA.y<<endl;
                                    if(ptA.y>90)
                                    {
                                        step=Step::turning;
                                    }
                                    break;
                                }
                            }
                        }
                        break;
                    }
                    case Step::turning: // 入库转向
                    {
                        if(track.topline>chargingPosion)
                            step=Step::stop;
                        break;
                    }
                    case Step::stop: // 停车
                    {
        
                        exit++;
                        if (exit > Chargingcount) // 倒车状态
                        {
                            exit = 0;
                            step = Step::trackout; // 开始倒车
                        }     
                        break;
                    }
                    case Step::trackout: // 出库
                    {
                        std::cout << "开始倒车" << std::endl;
                        if (Straight_Judge(track.edgeright,0,130)<1)
                            step = Step::exiting;
                        break;
                    }
                    case Step::exiting: // 出库
                    {
                        if (Straight_Judge(track.edgeleft,0,130)<1)
                        {
                            reset();
                            std::cout << "退出停车场" << std::endl;
                        }
                        break;
                    }
                }
            }
            else
            {
                switch (step)
                {
                    case Step::enable: // 停车场使能
                    {
                        for(int i=track.edgeright.size()-5;i>30;i--)
                        {
                        
                            if((track.edgeright[i-1].x-track.edgeright[i].x)>10&&track.Right_lose_judge[i-1])//loss_judge(track,30,i-1)
                            {
                                ptA=track.edgeright[i];
    
                                circle(image,ptA, 5, Scalar(0,0,255), FILLED);
                                line(image,Point(0,ptA.y),Point(319,ptA.y),Scalar(0,0,255),2);
                                cout<<ptA.y<<endl;
                                if(ptA.y>90)
                                {
                                    step=Step::turning;
                                }
                                break;
                            }
                        }
                        break;
                    }
                    case Step::turning: // 入库转向
                    {
                        if(track.topline>110)
                            step=Step::stop;
                        break;
                    }
                    case Step::stop: // 停车
                    {
        
                        exit++;
                        if (exit > Chargingcount) // 倒车状态
                        {
                            exit = 0;
                            step = Step::trackout; // 开始倒车
                        }     
                        break;
                    }
                    case Step::trackout: // 出库
                    {
                        std::cout << "开始倒车" << std::endl;
                        if (Straight_Judge(track.edgeleft,0,130)<1)
                            step = Step::exiting;
                        break;
                    }
                    case Step::exiting: // 出库
                    {
                        if (Straight_Judge(track.edgeright,0,130)<1)
                        {
                            reset();
                            std::cout << "退出停车场" << std::endl;
                        }
                        break;
                    }
                }
            }

            return true;
        }
        else // 检测标志
        {
            for (size_t i = 0; i < predict.size(); i++)
            {
                if (((predict[i].type == LABEL_BATTERY)  && predict[i].score > 0.6) ) //&& (predict[i].y + predict[i].height) > ROWSIMAGE * 0.1)
                {
                    counterRec++;
                    if (predict[i].x < COLSIMAGE / 2)   // 标识牌在左侧
                        ChargingLeft = true;
                    else
                        ChargingLeft = false;
                    break;
                }
            }

            if (counterRec)
            {
                counterSession++;
                if (counterRec >= 1 && counterSession < 8)
                {
                    counterRec = 0;
                    counterSession = 0;
                    step = Step::enable;   // 退出状态.
                    ChargingEnable = true; // 检测到标识牌子
                    noRing = true;
                    return true;
                }
                else if (counterSession >= 8)
                {
                    counterRec = 0;
                    counterSession = 0;
                }
            }

            return false;
        }
    }

    /**
     * @brief 识别结果图像绘制
     *
     */
    void drawImage(Tracking &track, Mat &image)
    {     
        if (ChargingEnable)
            putText(image, "[1] BATTERY - ENABLE", Point(COLSIMAGE / 2 - 30, 10), cv::FONT_HERSHEY_TRIPLEX, 0.3, cv::Scalar(0, 255, 0), 1, CV_AA);  
    }

    bool loss_judge(Tracking &track,int num,int b)
    {
        int a =0;

        for(int i=0; i<num;i++)
        {
            if(track.Right_lose_judge[b-i])
                a++;
        }

        if(a==num)
            return true;
        else
            return false;

    }

//private:
    uint16_t counterSession = 0;  // 图像场次计数器
    uint16_t counterRec = 0;      // 加油站标志检测计数器
    uint16_t exit = 0;            // 停车计数器 
    bool ChargingLeft = true;        // 左右库标志
    bool ChargingEnable = false;
    int lineY = 0;                // 直线高度
    bool startTurning = false;    // 开始转弯
    vector<int> Width; // 记录赛道宽度
    Point ptA = Point(0, 0);      // 记录线段的两个端点
    Point ptB = Point(0, 0);
    int stopTime = 45;                 // 停车时间 40帧
    int W;
};