/**
 * @file controlcenter.cpp
 * @brief 智能车控制中心计算
 */

#include "../include/include/src/controlcenter.hpp"

/******************************************************START******************************************************/
/**
 * @brief 控制中心计算
 * @param pointsEdgeLeft 赛道左边缘点集
 * @param pointsEdgeRight 赛道右边缘点集
 */
void ControlCenter::fitting(Tracking &track,CenterType centerType)
{
    centerEdge.clear();
    switch (centerType)
    {
        case CenterType::Mid:Midfitting(track);break;
        case CenterType::Left:Leftfitting(track);break;
        case CenterType::Right:Rightfitting(track);break;
        case CenterType::Left_Layby:Left_Layby_fitting(track);break;
        case CenterType::Right_Layby:Right_Layby_fitting(track);break;
        case CenterType::Left_Obstacle:ObstacleLeft(track);break;
        case CenterType::Right_Obstacle:ObstacleRight(track);break;
    }

    //边线延长
    if(centerEdge.size()<140)
    {
        int i=centerEdge.size();
        Point centerlastpoint=centerEdge[i-1];
        Point leftlastpoint=track.edgeleft[i-1];
        Point rightlastpoint=track.edgeright[i-1];
        for(i;i<140;i++)
        {
            centerEdge.push_back({centerlastpoint.x,centerlastpoint.y--});
            track.edgeright.push_back({319,rightlastpoint.y--});
            track.edgeleft.push_back({0,leftlastpoint.y--});
        }
    }
}

void ControlCenter::Midfitting(Tracking &track)
{
    vector<Point> v_center(4); // 三阶贝塞尔曲线
    v_center[0] = {
        (track.edgeleft[0].x + track.edgeright[0].x) / 2,
        (track.edgeleft[0].y + track.edgeright[0].y) / 2};

    v_center[1] = {
        (track.edgeleft[track.edgeleft.size() / 3].x +
        track.edgeright[track.edgeright.size() / 3].x) /
            2,
        (track.edgeleft[track.edgeleft.size() / 3].y +
        track.edgeright[track.edgeright.size() / 3].y) /
            2};

    v_center[2] = {
        (track.edgeleft[track.edgeleft.size() * 2 / 3].x +
        track.edgeright[track.edgeright.size() * 2 / 3].x) /
            2,
        (track.edgeleft[track.edgeleft.size() * 2 / 3].y +
        track.edgeright[track.edgeright.size() * 2 / 3].y) /
            2};

    v_center[3] = {
        (track.edgeleft[track.edgeleft.size() -1].x +
        track.edgeright[track.edgeright.size()-1].x) /
            2,
        (track.edgeleft[track.edgeleft.size()-1].y +
        track.edgeright[track.edgeright.size()-1].y) /
            2};

    //centerEdge = Bezier(0.9, v_center);
    for(int i=0;i<track.edgeleft.size();i++)
   {
        centerEdge.push_back(Point((int)(track.edgeleft[i].x + track.edgeright[i].x) / 2, track.edgeleft[i].y));
    }
}

void ControlCenter::Leftfitting(Tracking &track)
{
    for(int i=0;i<track.edgeleft.size();i++)
    {
        centerEdge.push_back(Point((int)(track.edgeleft[i].x + widths[i]/2), track.edgeleft[i].y));
    }
}

void ControlCenter::Rightfitting(Tracking &track)
{
    for(int i=0;i<track.edgeleft.size();i++)
    {
        centerEdge.push_back(Point((int)(track.edgeright[i].x - widths[i]/2), track.edgeright[i].y));
    }
}

void ControlCenter::Left_Layby_fitting(Tracking &track)
{
    for(int i=0;i<track.edgeleft.size();i++)
    {
        centerEdge.push_back(Point((int)(track.edgeright[i].x - widths[i]/4*3), track.edgeleft[i].y));
    }
}

void ControlCenter::Right_Layby_fitting(Tracking &track)
{
    for(int i=0;i<track.edgeright.size();i++)
    {
        centerEdge.push_back(Point((int)(track.edgeleft[i].x + widths[i]/4*3), track.edgeright[i].y));
    }  
}

void ControlCenter::ObstacleLeft(Tracking &track)
{
    for(int i=0;i<track.edgeleft.size();i++)
        centerEdge.push_back(Point((int)(track.edgeleft[i].x + widths[i]/6*1), track.edgeleft[i].y));      
}

void ControlCenter::ObstacleRight(Tracking &track)
{
    for(int i=0;i<track.edgeleft.size();i++)
        centerEdge.push_back(Point((int)(track.edgeright[i].x - widths[i]/6*1), track.edgeleft[i].y));     
}

/**
 * @brief 车辆冲出赛道检测（保护车辆）
 *
 * @param track
 * @return true
 * @return false
 */
bool ControlCenter::derailmentCheck(Mat &Binaryimg)
{
    int BlackA = 0;
    int BlackB = 0;
    int BlackC = 0;
    for (int i = 0; i < COLSIMAGE; i++)
    {
        if (Binaryimg.at<uchar>(194, i) == 0)
            BlackA++;
        if (Binaryimg.at<uchar>(195, i) == 0)
            BlackB++;
        if (Binaryimg.at<uchar>(196, i) == 0)
            BlackC++;
    }

    if (BlackA > 250
        &&BlackB > 250 
        &&BlackC > 250) // 防止车辆冲出赛道
    {
        countOutlineA++;
        countOutlineB = 0;
        if (countOutlineA > 5)
            return true;
    }
    else {
        countOutlineB++;
        if (countOutlineB > 50) {
            countOutlineA = 0;
            countOutlineB = 50;
        }
    }
    return false;
}