#pragma once

/** 
 * @file common.hpp
 * @brief 通用方法类
 */

#include "json.hpp"
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <opencv2/highgui.hpp> //OpenCV终端部署
#include <opencv2/opencv.hpp>  //OpenCV终端部署

using namespace std;
using namespace cv;

#define COLSIMAGE 320    // 图像的列数
#define ROWSIMAGE 240    // 图像的行数
#define PWMSERVOMAX 1030 // 舵机PWM最大值（左）1840
#define PWMSERVOMID 830 // 舵机PWM中值 1520
#define PWMSERVOMIN 630 // 舵机PWM最小值（右）1200
#define PI 3.1415926                                                

#define LABEL_BATTERY 0    // AI标签：充电站
#define LABEL_BLOCK 1      // AI标签：障碍物
#define LABEL_BRIDGE 2     // AI标签：坡道
#define LABEL_BURGER 3     // AI标签：汉堡
#define LABEL_CAR 4        // AI标签：道具车
#define LABEL_COMPANY 5    // AI标签：公司
#define LABEL_CONE 6       // AI标签：锥桶
#define LABEL_CROSSWALK 7  // AI标签：斑马线
#define LABEL_PEDESTRIAN 8 // AI标签：行人
#define LABEL_SCHOOL 9     // AI标签：学校

/**
 * @brief 场景类型（路况）
 */
enum Scene
{
    NormalScene = 0, // 基础赛道
    CrossScene,      // 十字道路
    RingScene,       // 环岛道路
    BridgeScene,     // 坡道区
    ObstacleScene,   // 障碍区
    CateringScene,   // 快餐店
    LaybyScene,      // 临时停车区
    ParkingScene,    // 停车区
    StopScene        // 停车（结束）
};

/**
 * @brief 中线拟合方式
 */
enum CenterType{
    Mid = 0, // 左右中值
    Left,    // 单边循左
    Right,   // 单边循右
    Left_Layby,//Layby循左
    Right_Layby,//Layby循右
    Left_Obstacle,
    Right_Obstacle,
};

/**
 * @brief Get the Scene object
 * @param scene
 * @return string
 */
string getScene(Scene scene)
{
    switch (scene)
    {
    case Scene::NormalScene:
        return "Normal";
    case Scene::CrossScene:
        return "Crossroad";
    case Scene::RingScene:
        return "Ring";
    case Scene::BridgeScene:
        return "Bridge";
    case Scene::ObstacleScene:
        return "Obstacle";
    case Scene::CateringScene:
        return "Catering";
    case Scene::LaybyScene:
        return "Layby";
    case Scene::ParkingScene:
        return "Parking";
    case Scene::StopScene:
        return "Stop";
    default:
        return "Error";
    }
}

/**
 * @brief 构建二维坐标
 *
 */
struct POINT
{
    int x = 0;
    int y = 0;
    float slope = 0.0f;

    POINT(){};
    POINT(int x, int y) : x(x), y(y){};
};

/**
 * @brief 存储图像至本地
 * @param image 需要存储的图像
 */
void savePicture(Mat &image)
{
    // 存图
    string name = ".jpg";
    static int counter = 0;
    counter++;
    string img_path = "../res/samples/train/";
    name = img_path + to_string(counter) + ".jpg";
    imwrite(name, image);
}

//--------------------------------------------------[公共方法]----------------------------------------------------
/**
 * @brief int集合平均值计算
 * @param arr 输入数据集合
 * @return double
 */
double average(vector<int> vec)
{
    if (vec.size() < 1)
        return -1;

    double sum = 0;
    for (int i = 0; i < vec.size(); i++)
    {
        sum += vec[i];
    }

    return (double)sum / vec.size();
}

/**
 * @brief int集合数据方差计算
 * @param vec Int集合
 * @return double
 */
double sigma(vector<int> vec)
{
    if (vec.size() < 1)
        return 0;

    double aver = average(vec); // 集合平均值
    double sigma = 0;
    for (int i = 0; i < vec.size(); i++)
    {
        sigma += (vec[i] - aver) * (vec[i] - aver);
    }
    sigma /= (double)vec.size();
    return sigma;
}

/**
 * @brief 赛道点集的方差计算
 * @param vec
 * @return double
 */
double sigma(vector<POINT> vec)
{
    if (vec.size() < 1)
        return 0;

    double sum = 0;
    for (int i = 0; i < vec.size(); i++)
    {
        sum += vec[i].y;
    }
    double aver = (double)sum / vec.size(); // 集合平均值

    double sigma = 0;
    for (int i = 0; i < vec.size(); i++)
    {
        sigma += (vec[i].y - aver) * (vec[i].y - aver);
    }
    sigma /= (double)vec.size();
    return sigma;
}

/**
 * @brief 阶乘计算
 * @param x
 * @return int
 */
int factorial(int x)
{
    int f = 1;
    for (int i = 1; i <= x; i++)
    {
        f *= i;
    }
    return f;
}

/**
 * @brief 贝塞尔曲线
 * @param dt
 * @param input
 * @return vector<Point>
 */
vector<Point> Bezier(double dt, vector<Point> input)
{
    vector<Point> output;

    double t = 0;
    while (t <= 1)
    {
        Point p;
        double x_sum = 0.0;
        double y_sum = 0.0;
        int i = 0;
        int n = input.size() - 1;
        while (i <= n)
        {
            double k =factorial(n) / (factorial(i) * factorial(n - i)) * pow(t, i) * pow(1 - t, n - i);
            x_sum += k * input[i].x;
            y_sum += k * input[i].y;
            i++;
        }
        p.x = x_sum;
        p.y = y_sum;
        output.push_back(p);
        t += dt;
    }
    return output;
}

/**
 * @brief double类型的数值val转换成字符串
 * @param val
 * @param fixed
 * @return string
 */
auto formatDoble2String(double val, int fixed)
{
    auto str = std::to_string(val);
    return str.substr(0, str.find(".") + fixed + 1);
}

/**
 * @brief 点到直线的距离计算
 * @param a 直线的起点
 * @param b 直线的终点
 * @param p 目标点
 * @return double
 */
double distanceForPoint2Line(POINT a, POINT b, POINT p)
{
    int d = 0; // 距离

    double ab_distance =
        sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
    double ap_distance =
        sqrt((a.x - p.x) * (a.x - p.x) + (a.y - p.y) * (a.y - p.y));
    double bp_distance =
        sqrt((p.x - b.x) * (p.x - b.x) + (p.y - b.y) * (p.y - b.y));

    double half = (ab_distance + ap_distance + bp_distance) / 2;
    double area = sqrt(half * (half - ab_distance) * (half - ap_distance) * (half - bp_distance));

    return (2 * area / ab_distance);
}

/**
 * @brief 两点之间的距离
 * @param a
 * @param b
 * @return double
 */
double distanceForPoints(POINT a, POINT b)
{
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

/**
 * @brief Angle_compute  获取三个坐标形成的夹角
 * @param 三个点的坐标(Point1,Point2,Point3)
 * @return degree_angle
 */
float Angle_compute(Point Point1,Point Point2,Point Point3)
{
    //计算Point2和Point1的距离dn1
    float dx1 =(float)( Point2.x-Point1.x );
    float dy1 =(float)( Point2.y-Point1.y );
    float dn1 = sqrtf(dx1 * dx1 + dy1 * dy1);

    //计算Point2和Point3的距离dn2
    float dx2 =(float)( Point2.x-Point3.x );
    float dy2 =(float)( Point2.y-Point3.y );
    float dn2 = sqrtf(dx2 * dx2 + dy2 * dy2);

    float c1 = dx1 / dn1;
    float s1 = dy1 / dn1;
    float c2 = dx2 / dn2;
    float s2 = dy2 / dn2;

    float degree_angle;

    return degree_angle =fabs( atan2f(c1 * s2 - c2 * s1, c2 * c1 + s2 * s1)/PI*180);
}

/**
 * @brief UI综合图像绘制
 */
class Display
{
private:
    bool enable = false; // 显示窗口使能
    int sizeWindow = 1;  // 窗口数量
    cv::Mat imgShow;     // 窗口图像
public:
    /**
     * @brief 显示窗口初始化
     * @param size 窗口数量(1~7)
     */
    Display(const int size)
    {
        if (size <= 0 || size > 7)
            return;

        // cv::namedWindow("ICAR", WINDOW_NORMAL);                // 图像名称
        // cv::resizeWindow("ICAR", COLSIMAGE * size, ROWSIMAGE); // 分辨率

        imgShow = cv::Mat::zeros(ROWSIMAGE, COLSIMAGE * size, CV_8UC3);
        enable = true;
        sizeWindow = size;
    };

    /**
     * @brief 设置新窗口属性
     * @param index 窗口序号
     * @param name 窗口名称
     * @param img 显示图像
     */
    void setNewWindow(int index, string name, Mat img)
    {
        // 数据溢出保护
        if (!enable || index <= 0 || index > sizeWindow)
            return;

        if (img.cols <= 0 || img.rows <= 0)
            return;

        Mat imgDraw = img.clone();

        if (imgDraw.type() == CV_8UC1) // 非RGB类型的图像
            cvtColor(imgDraw, imgDraw, cv::COLOR_GRAY2BGR);

        // 图像缩放
        if (imgDraw.cols != COLSIMAGE || imgDraw.rows != ROWSIMAGE)
        {
            float fx = COLSIMAGE / imgDraw.cols;
            float fy = ROWSIMAGE / imgDraw.rows;
            if (fx <= fy)
                resize(imgDraw, imgDraw, Size(COLSIMAGE, ROWSIMAGE), fx, fx);
            else
                resize(imgDraw, imgDraw, Size(COLSIMAGE, ROWSIMAGE), fy, fy);
        }

        // 限制图片标题长度
        string text = "[" + to_string(index) + "] ";
        if (name.length() > 15)
            text = text + name.substr(0, 15);
        else
            text = text + name;

        putText(imgDraw, text, Point(10, 20), cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(255, 0, 0), 0.5);

        Rect placeImg = cvRect(COLSIMAGE * (index - 1), 0, COLSIMAGE, ROWSIMAGE);
        imgDraw.copyTo(imgShow(placeImg));

        //savePicture(img); // 保存图像
    }

    /**
     * @brief 融合后的图像显示
     */
    void show(void)
    {
        if (enable)
            imshow("ICAR", imgShow);
    }
};

/**
 * @brief 补线函数
 * @param 俩点的坐标(Point1,Point2),绘制数量
 * @return points 
 */
vector<Point> interpolatePoints(const Point& p1, const Point& p2, int n)
{  
    vector<Point> points; 

    if (n <= 0 || p1 == p2)
    {
        return points; 
    } 

    double dx = static_cast<double>(p2.x - p1.x) / (n + 1);  
  
    for (int i = 0; i <= n; ++i) 
    {  
        points.emplace_back(static_cast<int>(p1.x + i * dx), static_cast<int>(p1.y - i));  
    }  

    return points;  
} 


/**
 * @brief 直线判断
 * @param pointsEdge 边线点集
 * @param start 起始行
 * @param end 终止行
 * @return S 小于1为直线
 */
float Straight_Judge(vector<Point> pointsEdge,int start, int end)     //返回结果小于1即为直线
{
    int i;
    float S = 0, Sum = 0, Err = 0, k = 0;
    if(pointsEdge.empty())
    {
        return 2;
    }
    if(end>pointsEdge.size()-1)
    {
        return 2;
    }
    
    k = (float)(pointsEdge[start].x - pointsEdge[end].x) / (start - end);
    for (i = 0; i < end - start; i++)
    {
            Err = (pointsEdge[start].x + k * i - pointsEdge[i+start].x)*(pointsEdge[start].x + k * i - pointsEdge[i+start].x);
            Sum += Err;
    }
        S = Sum / (end - start);
    return S;
}

/**
 * @brief  赛道宽度检测
 * @param pointsEdge 边线点集
 * @param start 起始行
 * @param end 终止行
 * @return S 白色点数(赛道宽度)
 */
uint16_t track_judgment(vector<Point> pointsEdgeLeft,vector<Point> pointsEdgeRight,uint16_t i)
{
    uint16_t trackwidth=0; //赛道宽度检测所需
    trackwidth = pointsEdgeRight[i].x-pointsEdgeLeft[i].x;
    return trackwidth;
}

/**
 * @brief  丢线检测
 * @param pointsEdge 边线点集
 * @param bool left 方向
 * @param start 起始行
 * @param end 终止行
 * @return bool
 */
bool loss_judgment(vector<Point> pointsEdge,bool left,uint16_t start,uint16_t end)
{
    int lossline=0;
    if(left)
    {
        for(int i=start;i<end;i++)
        {
            if(pointsEdge[i].x!=0)
            {
                lossline++;
            }
        }
        if(lossline==(end-start))
        {
            return true;
        }
    }
    else
    {
        for(int i=start;i<end;i++)
        {
            if(pointsEdge[i].x!=319)
            {
                lossline++;
            }
        }
        if(lossline==(end-start))
        {
            return true;
        }
    }

    return false;
}

int limit(int x, int a, int b)
{
    if(x<a) x = a;
    if(x>b) x = b;
    return x;
}

// 宽度数据数组（共110个元素，对应行号0到109）
int widths[] = {

    245,
    244,
    243,
    242,
    241,
    240,
    239,
    238,
    236,
    235,
    234,
    233,
    232,
    231,
    230,
    228,
    228,
    226,
    225,
    224,
    223,
    222,
    220,
    220,
    218,
    217,
    216,
    215,
    214,
    212,
    212,
    210,
    209,
    208,
    206,
    206,
    204,
    204,
    202,
    201,
    200,
    198,
    198,
    196,
    196,
    194,
    193,
    192,
    190,
    190,
    188,
    188,
    186,
    184,
    184,
    182,
    182,
    180,
    179,
    178,
    177,
    176,
    174,
    173,
    172,
    171,
    170,
    169,
    168,
    166,
    165,
    164,
    163,
    162,
    161,
    159,
    158,
    157,
    156,
    154,
    153,
    152,
    151,
    150,
    149,
    147,
    147,
    145,
    144,
    143,
    141,
    141,
    139,
    138,
    137,
    135,
    134,
    133,
    132,
    131,
    130,
    128,
    127,
    126,
    125,
    124,
    123,
    121,
    119,
    118,
    117,
    116,
    115,
    114,
    112,
    111,
    110,
    109,
    108,
    106,
    106,
    104,
    103,
    102,
    101,
    100,
    98,
    97,
    96,
    95,
    94,
    92,
    92,
    90,
    90,
    88,
    88,
    86,
    84,
    84      
};