#pragma once  

/** 
 * @file preprocess.hpp
 * @brief 图像预处理：RGB转灰度图，图像二值化
 * [1] 读取视频
 * [2] 图像二值化
 */

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>             
#include "../include/common.hpp"

using namespace cv;
using namespace std;

class Preprocess
{
public:
	/**
	 * @brief 图像矫正参数初始化
	 */
	Preprocess();

	/**
 	 * @brief 图像二值化
 	 * @param frame	输入原始帧
 	 * @return Mat	二值化图像
 	 */
	Mat binaryzation(Mat &frame);

	/**
 	 * @brief 图像左右黑色边界绘制
 	 * @param frame	输入二值化图像
	 * @param rowStart	图像的列数
	 * @param rowStart	图像底部切行
	 * @param rowCutUp	图像顶部切行
 	 */
	void black_border(Mat &frame);

	/**
 	 * @brief 矫正图像
 	 * @param imagesPath 图像路径
 	 */
	Mat correction(Mat &image);

private:
	bool enable =true;  // 图像矫正使能：初始化完成
	Mat cameraMatrix;	 // 摄像机内参矩阵
	Mat distCoeffs;		 // 相机的畸变矩阵
};