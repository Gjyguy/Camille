#pragma once  

/** 
 * @file mapping.cpp
 * @brief 图像的透视变换方法（逆/俯视）
 * @note 通过透视变换提取摄像头上帝视角（俯视）
 * @note IPM计算步骤：
 * [1] 设置逆透视图像的掩膜区域（mask）：包括目标变换区域和变换后的成像区域
 * [2] 求解变换矩阵和逆变矩阵
 * [3] 对图像或坐标进行变换
 */

 #include <iostream>
 #include <stdio.h>
 #include <ctime>
 #include <opencv2/highgui.hpp>
 #include <opencv2/opencv.hpp>
 #include "opencv2/core.hpp"
 #include "opencv2/imgproc.hpp"
 
 using namespace cv;
 using namespace std;
 
 #define RESULT_ROW 240 // 结果图行数（与图像高度一致）
 #define RESULT_COL 320 // 结果图列数（与图像宽度一致）
 #define USED_ROW 240   // 用于透视图的行数（这里与图像高度一致）
 #define USED_COL 320   // 用于透视图的列数（这里与图像宽度一致）
 
 class Mapping
 {
 public:
     Mat PER_IMG; // 用于透视变换的图像
     Mat ImageUsed;
     /**
      * @brief 逆透视
      * @param origSize 输入原始图像Img
      * @param dstSize 输出逆透视图像Img_Unpivot
      */
     void ImgUnpivot(Mat Img,Mat& Img_Unpivot);
 
     void ImagePerspective_Init(Mat& inputImage);
     
 private:
     // Points
     vector<Point2f> m_origPoints;
     vector<Point2f> m_dstPoints;
};
 