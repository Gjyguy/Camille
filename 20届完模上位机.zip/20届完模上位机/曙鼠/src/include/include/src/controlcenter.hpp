#pragma once  

/**
 * @file controlcenter.cpp
 * @brief 智能车控制中心计算
 */

#include <fstream>
#include <iostream>
#include <cmath>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../include/common.hpp"
#include "../src/recognition/tracking.cpp"

using namespace cv;
using namespace std;

class ControlCenter
{
public:
    int controlCenter;           // 智能车控制中心（0~320）
    vector<Point> centerEdge;    // 赛道中心点集
    vector<Point> pointsWidth;
    int countOutlineA = 0; // 车辆脱轨检测计数器
    int countOutlineB = 0; // 车辆脱轨检测计数器

    /**
     * @brief 控制中心计算
     * @param pointsEdgeLeft 赛道左边缘点集
     * @param pointsEdgeRight 赛道右边缘点集
     */
    void fitting(Tracking &track,CenterType centerType);

    void Midfitting(Tracking &track);

    void Leftfitting(Tracking &track);

    void Rightfitting(Tracking &track);

    void Left_Layby_fitting(Tracking &track);

    void Right_Layby_fitting(Tracking &track);

    void ObstacleLeft(Tracking &track);

    void ObstacleRight(Tracking &track);

    bool derailmentCheck(Mat &Binaryimg);
    /**
     * @brief 显示赛道线识别结果
     * @param centerImage 需要叠加显示的图像
     */
    void drawImage(Tracking track, Mat &centerImage)
    {
        //绘制中心点集
        for (int i = 0; i < centerEdge.size(); i++)
        {
            circle(centerImage, Point(centerEdge[i].x, centerEdge[i].y), 1, Scalar(0, 255, 0), -1);
        }
    }
};