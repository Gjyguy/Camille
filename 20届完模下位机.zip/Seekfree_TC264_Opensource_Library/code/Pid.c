/*
 * Pid.c
 *
 *  Created on: 2025��1��21��
 *      Author: 32428
 */
#include "Pid.h"

PIDStruct pidStr;

/**
* @brief        PID������ʼ��
* @param
* @ref
* @author       Leo
* @note
**/
void PID_Init(void)
{
    pidStr.Kp=5;
    pidStr.Ki=10;
    pidStr.Kd=0;

    pidStr.Err=0;
    pidStr.Err_last=0;
    pidStr.Out=0;
}

/**
* @brief        PID�ٿ�ģ��
* @param
* @ref
* @author       Leo
* @note
**/
float PID_MoveCalculate(float Target, float Feedback, PIDStruct *Pid)
{
    //�������
    Pid->Err = Target - Feedback;   //�������

    Pid->Out += Pid->Kp * (Pid->Err- Pid->Err_last)+ Pid->Ki * Pid->Err;
    Pid->Err_last = Pid->Err;

    return Pid->Out;
}
