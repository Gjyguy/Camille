/*
 * Motor.c
 *
 *  Created on: 2025��1��19��
 *      Author: 32428
 */
#include "Motor.h"

MotorStruct motorStr;

/**
* @brief        ������Ƴ�ʼ��
* @param
* @ref
* @author       Leo
* @note
**/
void MOTOR_Init(void)
{
    gpio_init(DIR, GPO, 1, GPO_PUSH_PULL);
    pwm_init(PWM, 17000, 0);

    //���ģ�ͳ�ʼ��
    encoder.Value = 0;
    motorStr.CloseLoop = true;                              //Ĭ�ϱջ�ģʽ
}

/**
* @brief        ������PWM����
* @param        pwm��-10000~10000
* @ref
* @author       Leo
* @note
**/
void MOTOR_SetPwmValue(int16 pwm)
{
    if(pwm>=0)
    {
        gpio_set_level(DIR, GPIO_HIGH);
        if(pwm>MOTOR_PWM_MAX)
        {
            pwm =MOTOR_PWM_MAX;
        }
        pwm_set_duty(PWM, pwm);
    }
    else if(pwm<0)
    {
        gpio_set_level(DIR, GPIO_LOW);
        if(pwm<MOTOR_PWM_MIN)
        {
            pwm=MOTOR_PWM_MIN;
        }
        pwm_set_duty(PWM, -pwm);
    }
}

/**
* @brief        ����ջ��ٿ�
* @param        speed���ٶ�m/s
* @ref
* @author       Leo
* @note
**/
void MOTOR_ControlLoop(float speed)
{
    if(speed > MOTOR_SPEED_MAX)
        speed = MOTOR_SPEED_MAX;
    else if(speed < -MOTOR_SPEED_MAX)
        speed = -MOTOR_SPEED_MAX;

    PID_MoveCalculate(speed,encoder.Value,&pidStr);
    if(pidStr.Out>MOTOR_PWM_MAX)
    {
        pidStr.Out=MOTOR_PWM_MAX;
    }
    else if(pidStr.Out<MOTOR_PWM_MIN)
    {
        pidStr.Out=MOTOR_PWM_MIN;
    }

    MOTOR_SetPwmValue((int16)pidStr.Out);
}

/**
* @brief        ��������߳�
* @param
* @ref
* @author       Leo
* @note
**/
void MOTOR_Timer(void)
{
    motorStr.Counter++;
    if(motorStr.Counter >= 5)                              //�ٿ�:10ms
    {
        ENCODER_RevSample();                                //����������

        if(motorStr.CloseLoop)        //�ջ�����
        {
            MOTOR_ControlLoop(icarStr.SpeedSet);        //�ջ��ٿ�
        }
        else
        {
            MOTOR_SetPwmValue(0);
        }

        motorStr.Counter = 0;
    }
}
