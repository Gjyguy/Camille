/*
 * Pit.h
 *
 *  Created on: 2025��1��19��
 *      Author: 32428
 */

#ifndef CODE_PIT_H_
#define CODE_PIT_H_

#include "zf_common_headfile.h"

void TIM2_Init(void);

#endif /* CODE_PIT_H_ */
