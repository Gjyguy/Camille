/*
 * Servo.c
 *
 *  Created on: 2025��1��19��
 *      Author: 32428
 */
#include "Servo.h"

ServoStruct servoStr;

void SERVO_Init(void)
{
    pwm_init(ATOM1_CH1_P33_9, 50, 8800);
}



/**
* @brief        ������PWM����
* @param        pwm��-20000~20000
* @ref
* @author       Leo
* @note
**/
void SERVO_SetPwmValue(signed int pwm)
{


    if(pwm < SERVO_PWM_MAX_R)
        pwm = SERVO_PWM_MAX_R;
    else if(pwm > SERVO_PWM_MAX_L)
        pwm = SERVO_PWM_MAX_L;


    pwm_set_duty(ATOM1_CH1_P33_9,pwm);
}





