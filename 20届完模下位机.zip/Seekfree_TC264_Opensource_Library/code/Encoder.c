/*
 * Encoder.c
 *
 *  Created on: 2025��1��21��
 *      Author: 32428
 */
#include "Encoder.h"

Encoder encoder;

/**
* @brief        ��������ʼ��
* @param
* @ref
* @author       Leo
* @note
**/
void ENCODER_Init(void)
{
    encoder_dir_init(TIM5_ENCODER,TIM5_ENCODER_CH1_P10_3,TIM5_ENCODER_CH2_P10_1);
    encoder_clear_count(TIM5_ENCODER);
}

/**
* @brief        ������ת�ٲ���
* @param
* @ref
* @author       Leo
* @note
**/
void ENCODER_RevSample(void)
{
    encoder.Value=encoder_get_count(TIM5_ENCODER);
    encoder.Valuetotal+=encoder.Value;
    encoder_clear_count(TIM5_ENCODER);
}



