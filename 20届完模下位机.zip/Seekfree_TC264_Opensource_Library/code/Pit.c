/*
 * Pit.c
 *
 *  Created on: 2025��1��19��
 *      Author: 32428
 */
#include "Pit.h"

void TIM2_Init(void)
{
    pit_ms_init(CCU60_CH0, 1);
}

